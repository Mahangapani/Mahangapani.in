/**
 * public/js/app.js
 * ─────────────────
 * Main application logic. Runs after api.js has loaded.
 *
 * Responsibilities:
 *   - Boot the app on DOMContentLoaded
 *   - Fetch and render real news from the backend
 *   - Wire up auth (login modal, register modal, user menu)
 *   - Replace hard-coded ticker with live breaking news
 *   - Render comment sections on article pages
 *   - Handle search
 *
 * The original HTML frontend already contains the markup structure
 * and CSS. This file targets the existing DOM IDs and populates
 * them with real data from our API instead of the static fallback data.
 */

// ─── State ────────────────────────────────────────────────────────────────────
let currentArticleId = null;  // tracks which article's comments are loaded
let currentPage      = 1;     // for pagination
let currentCategory  = 'all'; // category filter

// ─── Bootstrap ───────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initAuth();
  loadBreakingTicker();
  loadNews();
  loadTrending();
  bindSearch();
  bindCategoryNav();
  console.log('✅ Mahangapani frontend connected to backend');
});

// ─── AUTH INIT ────────────────────────────────────────────────────────────────
// Checks if a user is already logged in (token in localStorage) and
// updates the header UI to show their name / admin link.

function initAuth() {
  const user = Session.getUser();
  updateAuthUI(user);
  injectAuthModals();
}

function updateAuthUI(user) {
  // The header has a placeholder for auth buttons — we build it dynamically
  const headerActions = document.querySelector('.header-actions');
  if (!headerActions) return;

  // Remove any existing auth buttons (but keep theme / lang toggles)
  headerActions.querySelectorAll('.auth-dynamic').forEach(el => el.remove());

  if (user) {
    // Show the user's name + a logout button
    const userMenu = document.createElement('div');
    userMenu.className = 'auth-dynamic';
    userMenu.style.cssText = 'display:flex;align-items:center;gap:8px;';
    userMenu.innerHTML = `
      <span style="font-size:12px;color:var(--t2)">👤 ${user.name}</span>
      ${user.role === 'admin' ? `<a href="/admin.html" style="background:var(--gold);color:#000;border-radius:6px;padding:5px 10px;font-size:11px;font-weight:800;">⚙ Admin</a>` : ''}
      <button onclick="logout()" style="background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:5px 10px;font-size:11px;color:var(--t2);">Logout</button>
    `;
    headerActions.insertBefore(userMenu, headerActions.firstChild);
  } else {
    // Show Login / Register buttons
    const authBtns = document.createElement('div');
    authBtns.className = 'auth-dynamic';
    authBtns.style.cssText = 'display:flex;gap:6px;';
    authBtns.innerHTML = `
      <button onclick="openModal('login')" style="background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:6px 12px;font-size:12px;color:var(--t2);font-weight:600;">Login</button>
      <button onclick="openModal('register')" style="background:var(--red);color:#fff;border:none;border-radius:6px;padding:6px 12px;font-size:12px;font-weight:700;">Register</button>
    `;
    headerActions.insertBefore(authBtns, headerActions.firstChild);
  }
}

// ─── MODAL INJECTION ──────────────────────────────────────────────────────────
// Creates login + register modals and appends them to <body>.
// They are hidden by default and toggled with openModal / closeModal.

function injectAuthModals() {
  const modalStyles = `
    position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:2000;
    display:none;align-items:center;justify-content:center;backdrop-filter:blur(4px);
  `;
  const cardStyles = `
    background:var(--card);border:1px solid var(--border);border-radius:16px;
    padding:32px;width:90%;max-width:420px;position:relative;
  `;
  const inputStyles = `
    width:100%;background:var(--bg3);border:1.5px solid var(--border);border-radius:8px;
    padding:10px 14px;font-size:13px;color:var(--t1);outline:none;margin-bottom:12px;
  `;
  const btnStyles = `
    width:100%;padding:12px;border:none;border-radius:8px;font-size:14px;
    font-weight:800;cursor:pointer;margin-top:4px;
  `;

  const modalHTML = `
    <!-- Login Modal -->
    <div id="modal-login" style="${modalStyles}" onclick="if(event.target===this)closeModal('login')">
      <div style="${cardStyles}">
        <button onclick="closeModal('login')" style="position:absolute;top:12px;right:14px;background:none;border:none;font-size:20px;color:var(--t2);">×</button>
        <div style="font-family:var(--font-head);font-size:22px;font-weight:800;margin-bottom:6px;">Welcome back 👋</div>
        <div style="font-size:12px;color:var(--t2);margin-bottom:20px;">Log in to your Mahangapani account</div>
        <div id="login-error" style="display:none;background:rgba(232,0,26,.1);border:1px solid var(--red);border-radius:6px;padding:8px 12px;font-size:12px;color:var(--red);margin-bottom:12px;"></div>
        <input id="login-email" type="email" placeholder="Email address" style="${inputStyles}" />
        <input id="login-password" type="password" placeholder="Password" style="${inputStyles}" onkeydown="if(event.key==='Enter')submitLogin()" />
        <button onclick="submitLogin()" style="${btnStyles}background:linear-gradient(90deg,var(--red),var(--indigo));color:#fff;">Login</button>
        <div style="text-align:center;margin-top:14px;font-size:12px;color:var(--t2);">
          No account? <span onclick="closeModal('login');openModal('register')" style="color:var(--red);cursor:pointer;font-weight:700;">Register</span>
        </div>
      </div>
    </div>

    <!-- Register Modal -->
    <div id="modal-register" style="${modalStyles}" onclick="if(event.target===this)closeModal('register')">
      <div style="${cardStyles}">
        <button onclick="closeModal('register')" style="position:absolute;top:12px;right:14px;background:none;border:none;font-size:20px;color:var(--t2);">×</button>
        <div style="font-family:var(--font-head);font-size:22px;font-weight:800;margin-bottom:6px;">Create account 🚀</div>
        <div style="font-size:12px;color:var(--t2);margin-bottom:20px;">Join Mahangapani — free forever</div>
        <div id="reg-error" style="display:none;background:rgba(232,0,26,.1);border:1px solid var(--red);border-radius:6px;padding:8px 12px;font-size:12px;color:var(--red);margin-bottom:12px;"></div>
        <input id="reg-name" type="text" placeholder="Your full name" style="${inputStyles}" />
        <input id="reg-email" type="email" placeholder="Email address" style="${inputStyles}" />
        <input id="reg-password" type="password" placeholder="Password (min 6 chars, 1 uppercase, 1 number)" style="${inputStyles}" onkeydown="if(event.key==='Enter')submitRegister()" />
        <button onclick="submitRegister()" style="${btnStyles}background:linear-gradient(90deg,var(--red),var(--indigo));color:#fff;">Create Account</button>
        <div style="text-align:center;margin-top:14px;font-size:12px;color:var(--t2);">
          Have an account? <span onclick="closeModal('register');openModal('login')" style="color:var(--red);cursor:pointer;font-weight:700;">Login</span>
        </div>
      </div>
    </div>
  `;

  const div = document.createElement('div');
  div.innerHTML = modalHTML;
  document.body.appendChild(div);
}

function openModal(name) {
  const el = document.getElementById(`modal-${name}`);
  if (el) el.style.display = 'flex';
}
function closeModal(name) {
  const el = document.getElementById(`modal-${name}`);
  if (el) el.style.display = 'none';
}

// ─── AUTH ACTIONS ─────────────────────────────────────────────────────────────

async function submitLogin() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const errEl    = document.getElementById('login-error');
  errEl.style.display = 'none';

  if (!email || !password) {
    errEl.textContent = 'Please enter email and password.';
    errEl.style.display = 'block';
    return;
  }

  try {
    const res = await AuthAPI.login(email, password);
    Session.save(res.token, res.user);
    closeModal('login');
    updateAuthUI(res.user);
    showToast(`Welcome back, ${res.user.name}! 👋`);
  } catch (err) {
    errEl.textContent = err.message;
    errEl.style.display = 'block';
  }
}

async function submitRegister() {
  const name     = document.getElementById('reg-name').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;
  const errEl    = document.getElementById('reg-error');
  errEl.style.display = 'none';

  if (!name || !email || !password) {
    errEl.textContent = 'All fields are required.';
    errEl.style.display = 'block';
    return;
  }

  try {
    const res = await AuthAPI.register(name, email, password);
    Session.save(res.token, res.user);
    closeModal('register');
    updateAuthUI(res.user);
    showToast(`Account created! Welcome, ${res.user.name} 🎉`);
  } catch (err) {
    errEl.textContent = err.message;
    errEl.style.display = 'block';
  }
}

function logout() {
  Session.clear();
  updateAuthUI(null);
  showToast('Logged out successfully.', 'info');
}

// Make auth functions global so HTML onclick attributes can call them
window.openModal      = openModal;
window.closeModal     = closeModal;
window.submitLogin    = submitLogin;
window.submitRegister = submitRegister;
window.logout         = logout;

// ─── BREAKING NEWS TICKER ─────────────────────────────────────────────────────
// Replaces the hard-coded ticker items with live breaking news from the DB.

async function loadBreakingTicker() {
  const tickerInner = document.getElementById('ticker-inner');
  if (!tickerInner) return;

  try {
    const { data } = await NewsAPI.getBreaking();
    if (!data?.length) return; // keep the static fallback if API returns nothing

    const items = [...data, ...data]; // duplicate for seamless loop
    tickerInner.innerHTML = items
      .map(a => `<span class="ticker-item" style="cursor:pointer" onclick="openArticle('${a.slug}')">◆ ${a.title}</span>`)
      .join('');
  } catch (err) {
    console.warn('[Ticker] Could not load breaking news:', err.message);
    // The original static ticker content remains as fallback
  }
}

// ─── NEWS GRID LOADING ────────────────────────────────────────────────────────

async function loadNews(category = 'all', page = 1) {
  const latestGrid = document.getElementById('latest-grid');
  const heroGrid   = document.getElementById('hero-grid');
  if (!latestGrid) return;

  // Show skeleton cards while loading
  latestGrid.innerHTML = Array(8).fill(
    `<div class="news-card"><div class="news-card-img skeleton" style="height:130px"></div>
     <div class="news-card-body"><div class="skeleton" style="height:14px;margin-bottom:8px"></div>
     <div class="skeleton" style="height:12px;width:70%"></div></div></div>`
  ).join('');

  try {
    const params = { page, limit: 12 };
    if (category !== 'all') params.category = category;

    const { data, pagination } = await NewsAPI.getAll(params);
    currentPage = pagination.page;

    // ── Hero section (first article) ──────────────────────────────────────────
    if (heroGrid && page === 1 && data.length > 0) {
      const hero   = data[0];
      const sideA  = data[1] || hero;
      const sideB  = data[2] || hero;

      heroGrid.innerHTML = `
        <div class="hero-main" onclick="openArticle('${hero.slug}')">
          <img class="card-img" src="${hero.image_url || 'https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=800&q=80'}" alt="${escHtml(hero.title)}" onerror="this.src='https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&q=80'" />
          <div class="card-overlay"></div>
          <div style="position:absolute;top:12px;left:12px;right:12px;display:flex;justify-content:space-between;align-items:flex-start;">
            <div style="display:flex;gap:6px;">
              ${hero.is_breaking ? '<span class="live-badge"><span style="width:5px;height:5px;border-radius:50%;background:#fff;display:inline-block;"></span> LIVE</span>' : ''}
              ${hero.is_hot ? '<span class="hot-badge">🔥 HOT</span>' : ''}
            </div>
          </div>
          <div class="card-content">
            <div class="card-meta">${catChip(hero.category_slug)}<span style="color:rgba(255,255,255,.5);font-size:11px">${escHtml(hero.source||'')}</span><span style="color:rgba(255,255,255,.35);font-size:11px">· ${timeAgo(hero.published_at)}</span></div>
            <div class="card-title">${escHtml(hero.title)}</div>
            <div class="card-summary">${escHtml((hero.summary||'').slice(0,120))}…</div>
            <div class="card-footer"><div class="source-dot"><span class="source-name">${escHtml(hero.source||'')}</span></div><span class="card-views">👁 ${fmtNum(hero.views)} · ${hero.read_time||'3 min'}</span></div>
          </div>
        </div>
        <div class="hero-side">
          ${[sideA, sideB].map(a => `
            <div class="hero-side-card" onclick="openArticle('${a.slug}')">
              <img class="card-img" src="${a.image_url || 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=600&q=80'}" alt="" onerror="this.src='https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&q=80'" />
              <div class="card-overlay"></div>
              <div class="card-content">
                <div class="card-meta">${catChip(a.category_slug)}</div>
                <div class="card-title" style="font-size:14px">${escHtml(a.title)}</div>
                <div style="font-size:9px;color:rgba(255,255,255,.45);margin-top:4px">${escHtml(a.source||'')} · ${timeAgo(a.published_at)}</div>
              </div>
            </div>
          `).join('')}
        </div>
      `;
    }

    // ── News card grid (articles 3 onward) ────────────────────────────────────
    const gridArticles = page === 1 ? data.slice(3) : data;
    latestGrid.innerHTML = gridArticles.map(a => newsCardHTML(a)).join('');

    // ── Pagination controls ───────────────────────────────────────────────────
    renderPagination(pagination, (p) => loadNews(currentCategory, p));

  } catch (err) {
    latestGrid.innerHTML = `<div style="grid-column:1/-1;padding:24px;color:var(--t2);text-align:center;">
      ⚠ Could not load news: ${escHtml(err.message)}
      <br><button onclick="loadNews()" style="margin-top:12px;padding:8px 16px;background:var(--red);color:#fff;border:none;border-radius:6px;cursor:pointer;">Retry</button>
    </div>`;
    console.error('[News] Load error:', err);
  }
}

// ─── TRENDING SIDEBAR ─────────────────────────────────────────────────────────

async function loadTrending() {
  const trendingList = document.getElementById('trending-list');
  if (!trendingList) return;

  try {
    const { data } = await NewsAPI.getTrending();
    trendingList.innerHTML = data.map((a, i) => `
      <div class="rank-card" onclick="openArticle('${a.slug}')">
        <div class="rank-num ${i > 2 ? 'gray' : ''}">${i + 1}</div>
        <img class="rank-thumb" src="${a.image_url || 'https://images.unsplash.com/photo-1532375810709-75b1da00537c?w=200&q=80'}" alt="" onerror="this.src='https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=200&q=80'" />
        <div>
          <div class="rank-title line-clamp-2">${escHtml(a.title)}</div>
          <div class="rank-meta">${timeAgo(a.published_at)} · 👁 ${fmtNum(a.views)}</div>
        </div>
      </div>
    `).join('');
  } catch (err) {
    console.warn('[Trending] Error:', err.message);
  }
}

// ─── ARTICLE PAGE ─────────────────────────────────────────────────────────────
// Opens a full article by replacing the current page content.

async function openArticle(slug) {
  showPage('article');

  const container = document.getElementById('article-content');
  if (!container) return;

  container.innerHTML = `
    <div style="padding:40px 0;text-align:center;">
      <div style="width:40px;height:40px;border:3px solid var(--red);border-top-color:transparent;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 12px;"></div>
      <div style="color:var(--t2)">Loading article…</div>
    </div>
  `;

  try {
    const { data: article, related } = await NewsAPI.getOne(slug);
    currentArticleId = article.id;

    // Build SEO meta tags dynamically
    document.title = `${article.title} | Mahangapani`;
    setMeta('description', article.summary || article.title);
    setMeta('og:title',    article.title);
    setMeta('og:description', article.summary || '');
    setMeta('og:image',    article.image_url || '');

    container.innerHTML = `
      <span class="back-btn" onclick="showPage('home');loadNews()">← Back to Home</span>
      ${catChip(article.category_slug)}
      <h1 class="article-headline">${escHtml(article.title)}</h1>
      ${article.title_hi ? `<div style="font-family:var(--font-dev);font-size:18px;color:var(--t2);margin-bottom:12px;">${escHtml(article.title_hi)}</div>` : ''}
      <div class="article-meta">
        <span>✍ ${escHtml(article.author || article.source || 'Staff Reporter')}</span>
        <span>🕐 ${timeAgo(article.published_at)}</span>
        <span>👁 ${fmtNum(article.views)} views</span>
        <span>📖 ${article.read_time || '3 min'} read</span>
      </div>
      ${article.image_url ? `<img class="article-hero-img" src="${article.image_url}" alt="${escHtml(article.title)}" onerror="this.style.display='none'" />` : ''}
      <div class="article-body">
        <p>${escHtml(article.summary || '')}</p>
        ${article.summary_hi ? `<p style="font-family:var(--font-dev);color:var(--t2);">${escHtml(article.summary_hi)}</p>` : ''}
        ${(article.content || '').split('\n').filter(p => p.trim()).map(p => `<p>${escHtml(p)}</p>`).join('')}
      </div>
      <div class="article-tags">
        ${(JSON.parse(article.tags || '[]')).map(t => `<span class="article-tag">#${escHtml(t)}</span>`).join('')}
      </div>
      <div class="article-actions">
        <button id="like-btn" class="action-btn" onclick="likeCurrentArticle(${article.id}, this)">❤ Like <span id="like-count">${article.likes}</span></button>
        <button class="action-btn" onclick="shareArticle('${slug}','${escHtml(article.title)}')">📤 Share</button>
        ${article.source_url ? `<a class="action-btn" href="${article.source_url}" target="_blank" rel="noopener">🔗 Source</a>` : ''}
      </div>

      <!-- RELATED ARTICLES -->
      ${related?.length ? `
        <div style="margin-top:32px">
          <div class="section-head">
            <div class="section-bar" style="background:var(--red)"></div>
            <div class="section-title">Related Articles</div>
          </div>
          <div class="related-grid">
            ${related.map(r => `
              <div class="related-card" onclick="openArticle('${r.slug}')">
                <div class="related-card-img">
                  <img src="${r.image_url || 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&q=80'}" alt="" onerror="this.src='https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&q=80'" />
                  ${catChip(r.category_slug)}
                </div>
                <div class="related-card-body"><div class="related-title">${escHtml(r.title)}</div></div>
              </div>
            `).join('')}
          </div>
        </div>
      ` : ''}

      <!-- COMMENTS SECTION -->
      <div id="comments-section" style="margin-top:40px">
        <div class="section-head">
          <div class="section-bar" style="background:var(--blue)"></div>
          <div class="section-title">Comments</div>
        </div>
        ${buildCommentForm(article.id)}
        <div id="comments-list"><div style="color:var(--t2);padding:16px 0;">Loading comments…</div></div>
      </div>
    `;

    loadComments(article.id);
  } catch (err) {
    container.innerHTML = `<div style="padding:40px;text-align:center;color:var(--t2);">
      ❌ ${escHtml(err.message)}<br>
      <button onclick="showPage('home')" style="margin-top:16px;padding:10px 20px;background:var(--red);color:#fff;border:none;border-radius:8px;cursor:pointer;">← Back Home</button>
    </div>`;
  }
}

window.openArticle = openArticle;

// ─── LIKE ─────────────────────────────────────────────────────────────────────
async function likeCurrentArticle(id, btn) {
  try {
    const { likes } = await NewsAPI.like(id);
    document.getElementById('like-count').textContent = likes;
    btn.classList.add('liked');
  } catch (err) {
    showToast(err.message, 'error');
  }
}
window.likeCurrentArticle = likeCurrentArticle;

// ─── SHARE ────────────────────────────────────────────────────────────────────
function shareArticle(slug, title) {
  const url = `${window.location.origin}/?article=${slug}`;
  if (navigator.share) {
    navigator.share({ title, url });
  } else {
    navigator.clipboard.writeText(url).then(() => showToast('Link copied!'));
  }
}
window.shareArticle = shareArticle;

// ─── COMMENTS ─────────────────────────────────────────────────────────────────

function buildCommentForm(articleId) {
  const user = Session.getUser();
  return `
    <div style="background:var(--card);border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:16px;">
      ${!user ? `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:10px;">
          <input id="guest-name"  placeholder="Your name *" style="padding:8px 12px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;color:var(--t1);font-size:12px;" />
          <input id="guest-email" placeholder="Email (optional)" style="padding:8px 12px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;color:var(--t1);font-size:12px;" />
        </div>
      ` : `<div style="font-size:12px;color:var(--t2);margin-bottom:8px;">Commenting as <b style="color:var(--t1)">${user.name}</b></div>`}
      <textarea id="comment-body" placeholder="Write a comment…" rows="3" style="width:100%;padding:10px 12px;background:var(--bg3);border:1.5px solid var(--border);border-radius:8px;color:var(--t1);font-size:13px;resize:vertical;outline:none;"></textarea>
      <button onclick="submitComment(${articleId})" style="margin-top:8px;padding:9px 20px;background:var(--red);color:#fff;border:none;border-radius:7px;font-weight:700;font-size:12px;cursor:pointer;">Post Comment</button>
    </div>
  `;
}

async function loadComments(articleId) {
  const list = document.getElementById('comments-list');
  if (!list) return;

  try {
    const { data, total } = await CommentsAPI.getAll(articleId);
    if (!data.length) {
      list.innerHTML = `<div style="color:var(--t2);padding:12px 0;font-size:13px;">No comments yet. Be the first to comment!</div>`;
      return;
    }
    list.innerHTML = `<div style="font-size:12px;color:var(--t2);margin-bottom:12px;">${total} comment${total !== 1 ? 's' : ''}</div>` +
      data.map(c => commentHTML(c, articleId)).join('');
  } catch (err) {
    list.innerHTML = `<div style="color:var(--t2);">Could not load comments.</div>`;
  }
}
window.loadComments = loadComments;

function commentHTML(c, articleId) {
  return `
    <div style="border-bottom:1px solid var(--border);padding:14px 0;" id="comment-${c.id}">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
        <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--red),var(--indigo));display:flex;align-items:center;justify-content:center;font-size:12px;color:#fff;font-weight:700;">${(c.display_name||'?')[0].toUpperCase()}</div>
        <span style="font-size:13px;font-weight:700;color:var(--t1);">${escHtml(c.display_name)}</span>
        ${c.user_role === 'admin' ? '<span style="font-size:9px;background:var(--red);color:#fff;padding:1px 6px;border-radius:3px;font-weight:800;">ADMIN</span>' : ''}
        <span style="font-size:11px;color:var(--t3);">${timeAgo(c.created_at)}</span>
      </div>
      <div style="font-size:13px;color:var(--t2);line-height:1.6;padding-left:36px;">${escHtml(c.body)}</div>
      <div style="padding-left:36px;margin-top:8px;display:flex;gap:12px;">
        <button onclick="likeComment(${c.id},this)" style="background:none;border:none;font-size:11px;color:var(--t3);cursor:pointer;">❤ <span id="clikes-${c.id}">${c.likes}</span></button>
        <button onclick="showReplyForm(${c.id},${articleId})" style="background:none;border:none;font-size:11px;color:var(--t3);cursor:pointer;">↩ Reply</button>
        ${Session.getUser() ? `<button onclick="deleteComment(${c.id})" style="background:none;border:none;font-size:11px;color:var(--red);cursor:pointer;">🗑 Delete</button>` : ''}
      </div>
      <div id="reply-form-${c.id}" style="display:none;margin-left:36px;margin-top:10px;"></div>
      ${c.replies?.length ? `<div style="margin-left:36px;margin-top:8px;border-left:2px solid var(--border);padding-left:14px;">${c.replies.map(r => commentHTML(r, articleId)).join('')}</div>` : ''}
    </div>
  `;
}

async function submitComment(articleId, parentId = null) {
  const body       = document.getElementById(parentId ? `reply-body-${parentId}` : 'comment-body')?.value?.trim();
  const guestName  = document.getElementById('guest-name')?.value?.trim()  || null;
  const guestEmail = document.getElementById('guest-email')?.value?.trim() || null;

  if (!body) { showToast('Please write a comment.', 'error'); return; }

  try {
    await CommentsAPI.add(articleId, body, parentId, guestName, guestEmail);
    showToast('Comment posted! 🎉');
    loadComments(articleId);
    if (parentId) {
      const rf = document.getElementById(`reply-form-${parentId}`);
      if (rf) rf.style.display = 'none';
    } else {
      const el = document.getElementById('comment-body');
      if (el) el.value = '';
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}
window.submitComment = submitComment;

async function likeComment(id, btn) {
  try {
    const { likes } = await CommentsAPI.like(id);
    const span = document.getElementById(`clikes-${id}`);
    if (span) span.textContent = likes;
  } catch {}
}
window.likeComment = likeComment;

async function deleteComment(id) {
  if (!confirm('Delete this comment?')) return;
  try {
    await CommentsAPI.delete(id);
    const el = document.getElementById(`comment-${id}`);
    if (el) el.remove();
    showToast('Comment deleted.', 'info');
  } catch (err) {
    showToast(err.message, 'error');
  }
}
window.deleteComment = deleteComment;

function showReplyForm(commentId, articleId) {
  const container = document.getElementById(`reply-form-${commentId}`);
  if (!container) return;
  const isVisible = container.style.display !== 'none';
  if (isVisible) { container.style.display = 'none'; return; }

  container.style.display = 'block';
  container.innerHTML = `
    <textarea id="reply-body-${commentId}" placeholder="Write a reply…" rows="2" style="width:100%;padding:8px 10px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;color:var(--t1);font-size:12px;resize:vertical;outline:none;"></textarea>
    <div style="display:flex;gap:8px;margin-top:6px;">
      <button onclick="submitComment(${articleId},${commentId})" style="padding:6px 14px;background:var(--red);color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;">Reply</button>
      <button onclick="this.closest('#reply-form-${commentId}').style.display='none'" style="padding:6px 12px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;font-size:11px;cursor:pointer;">Cancel</button>
    </div>
  `;
}
window.showReplyForm = showReplyForm;

// ─── SEARCH ───────────────────────────────────────────────────────────────────

function bindSearch() {
  // The original HTML has id="search-input" on the header search box
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    searchInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') doSearch(searchInput.value.trim());
    });
  }
  // Also bind the search page's large input
  const bigInput = document.getElementById('search-big-input');
  if (bigInput) {
    bigInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') doSearch(bigInput.value.trim());
    });
  }
}

async function doSearch(query) {
  if (!query || query.length < 2) return;
  showPage('search');

  // Sync the search-page input value
  const bigInput = document.getElementById('search-big-input');
  if (bigInput) bigInput.value = query;

  const resultsEl = document.getElementById('search-results');
  if (!resultsEl) return;

  resultsEl.innerHTML = `<div style="color:var(--t2);padding:20px 0">Searching for "${escHtml(query)}"…</div>`;

  try {
    const { data, pagination } = await NewsAPI.search(query);
    if (!data.length) {
      resultsEl.innerHTML = `<div style="color:var(--t2);padding:20px 0">No results found for "<b>${escHtml(query)}</b>". Try different keywords.</div>`;
      return;
    }

    resultsEl.innerHTML = `
      <div style="margin-bottom:16px;font-size:13px;color:var(--t2);">Found <b style="color:var(--red)">${pagination.total}</b> results for "<b>${escHtml(query)}</b>"</div>
      ${data.map(a => `
        <div class="search-result-card" onclick="openArticle('${a.slug}')">
          <img class="search-result-img" src="${a.image_url || 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=200&q=80'}" alt="" onerror="this.src='https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=200&q=80'" />
          <div class="search-result-body">
            <div class="search-result-title">${escHtml(a.title)}</div>
            <div class="search-result-summary">${escHtml((a.summary||'').slice(0,150))}…</div>
            <div class="search-result-meta">${catChip(a.category_slug)} · ${escHtml(a.source||'')} · ${timeAgo(a.published_at)}</div>
          </div>
        </div>
      `).join('')}
    `;
  } catch (err) {
    resultsEl.innerHTML = `<div style="color:var(--red);">Search error: ${escHtml(err.message)}</div>`;
  }
}
window.doSearch = doSearch;
window.runSearch = () => {
  const v = document.getElementById('search-big-input')?.value?.trim();
  if (v) doSearch(v);
};

// ─── CATEGORY NAV ─────────────────────────────────────────────────────────────

function bindCategoryNav() {
  document.querySelectorAll('.cat-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // Extract category slug from the button's onclick text or data attribute
      const onclickText = btn.getAttribute('onclick') || '';
      const match = onclickText.match(/filterCat\('([^']+)'/);
      const cat = match ? match[1] : 'all';
      currentCategory = cat;
      loadNews(cat === 'all' ? undefined : cat, 1);
    });
  });
}

// ─── PAGINATION ───────────────────────────────────────────────────────────────

function renderPagination({ page, pages }, onPage) {
  let el = document.getElementById('pagination-bar');
  if (!el) {
    el = document.createElement('div');
    el.id = 'pagination-bar';
    el.style.cssText = 'display:flex;justify-content:center;gap:8px;padding:24px 0;flex-wrap:wrap;';
    const grid = document.getElementById('latest-grid');
    if (grid) grid.insertAdjacentElement('afterend', el);
  }

  if (pages <= 1) { el.innerHTML = ''; return; }

  const btnStyle = (active) =>
    `padding:8px 14px;border-radius:7px;border:1.5px solid ${active ? 'var(--red)' : 'var(--border)'};background:${active ? 'var(--red)' : 'var(--bg3)'};color:${active ? '#fff' : 'var(--t2)'};font-weight:700;font-size:12px;cursor:pointer;`;

  const nums = [];
  for (let i = Math.max(1, page - 2); i <= Math.min(pages, page + 2); i++) nums.push(i);

  el.innerHTML = `
    ${page > 1 ? `<button style="${btnStyle(false)}" onclick="(${onPage})(${page - 1})">← Prev</button>` : ''}
    ${nums.map(n => `<button style="${btnStyle(n === page)}" onclick="(${onPage})(${n})">${n}</button>`).join('')}
    ${page < pages ? `<button style="${btnStyle(false)}" onclick="(${onPage})(${page + 1})">Next →</button>` : ''}
  `;
}

// ─── HANDLE DIRECT ARTICLE LINK ───────────────────────────────────────────────
// If someone visits /?article=some-slug, open that article directly.
(function handleDeepLink() {
  const slug = new URLSearchParams(window.location.search).get('article');
  if (slug) {
    // Wait for DOM before opening
    document.addEventListener('DOMContentLoaded', () => openArticle(slug));
  }
})();

// ─── UTILITY FUNCTIONS ────────────────────────────────────────────────────────

/** escHtml — prevents XSS by escaping user content before putting it in innerHTML */
function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** timeAgo — converts an ISO/SQLite date to "2 hours ago" */
function timeAgo(dateStr) {
  if (!dateStr) return '';
  const diff = (Date.now() - new Date(dateStr).getTime()) / 1000;
  if (diff < 60)   return 'just now';
  if (diff < 3600) return `${Math.floor(diff/60)} min ago`;
  if (diff < 86400) return `${Math.floor(diff/3600)} hrs ago`;
  return `${Math.floor(diff/86400)} days ago`;
}

/** fmtNum — "12345" → "12.3K" */
function fmtNum(n) {
  if (!n) return '0';
  if (n >= 1000000) return (n / 1000000).toFixed(1) + 'M';
  if (n >= 1000)    return (n / 1000).toFixed(1) + 'K';
  return String(n);
}

/** catChip — colored category label badge */
const CAT_COLORS = {
  india:'#FF6600', politics:'#8B5CF6', world:'#0EA5E9', business:'#10B981',
  tech:'#6366F1', sports:'#E8001A', entertainment:'#EC4899', health:'#10B981',
  crime:'#64748B', science:'#0891B2',
};
const CAT_NAMES = {
  india:'India', politics:'Politics', world:'World', business:'Business',
  tech:'Tech', sports:'Sports', entertainment:'Entertainment',
  health:'Health', crime:'Crime', science:'Science',
};

function catChip(slug) {
  const color = CAT_COLORS[slug] || '#64748B';
  const name  = CAT_NAMES[slug]  || (slug || '').toUpperCase();
  return `<span class="cat-chip" style="background:${color};color:#fff">${escHtml(name)}</span>`;
}

/** newsCardHTML — renders a single card in the latest-news grid */
function newsCardHTML(a) {
  return `
    <div class="news-card" onclick="openArticle('${a.slug}')">
      <div class="news-card-img">
        <img src="${a.image_url || 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&q=80'}" alt="" onerror="this.src='https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&q=80'" />
        <div class="news-card-img-overlay"></div>
        ${a.is_breaking ? '<div class="news-card-top"><span class="live-badge" style="font-size:8px;"><span style="width:4px;height:4px;border-radius:50%;background:#fff;display:inline-block;"></span> LIVE</span></div>' : ''}
      </div>
      <div class="news-card-body">
        <div class="news-card-meta">${catChip(a.category_slug)}<span style="font-size:9px;color:var(--t3);">· ${timeAgo(a.published_at)}</span></div>
        <div class="news-card-title line-clamp-2">${escHtml(a.title)}</div>
        <div class="news-card-footer"><span class="news-source">${escHtml(a.source||'')}</span><span class="news-views">👁 ${fmtNum(a.views)}</span></div>
      </div>
    </div>
  `;
}

/** setMeta — creates or updates a <meta> tag for SEO */
function setMeta(name, content) {
  if (!content) return;
  const prop = name.startsWith('og:') ? 'property' : 'name';
  let el = document.querySelector(`meta[${prop}="${name}"]`);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(prop, name);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}
