/**
 * config/index.js
 * ───────────────
 * Single source of truth for all runtime configuration.
 * Every value comes from environment variables so the same code
 * runs in development, staging, and production without changes.
 *
 * Pattern: export a plain object so any module can do:
 *   const { jwt, newsApi } = require('../config');
 */

require('dotenv').config();

module.exports = {
  // ── Server ────────────────────────────────────────────────────────────────
  port: parseInt(process.env.PORT, 10) || 5000,
  nodeEnv: process.env.NODE_ENV || 'development',
  isDev: (process.env.NODE_ENV || 'development') === 'development',
  frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5000',

  // ── JWT ───────────────────────────────────────────────────────────────────
  // The secret MUST be a long random string in production.
  // Generate one: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
  jwt: {
    secret:    process.env.JWT_SECRET    || 'change_this_in_production',
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  },

  // ── NewsAPI ───────────────────────────────────────────────────────────────
  // Free tier: 500 requests/day. Register at https://newsapi.org
  newsApi: {
    key:      process.env.NEWS_API_KEY      || '',
    country:  process.env.NEWS_API_COUNTRY  || 'in',
    pageSize: parseInt(process.env.NEWS_API_PAGE_SIZE, 10) || 30,
    baseUrl:  'https://newsapi.org/v2',
  },

  // ── Anthropic (AI summaries) ──────────────────────────────────────────────
  anthropic: {
    apiKey: process.env.ANTHROPIC_API_KEY || '',
    model:  'claude-haiku-4-5-20251001', // fastest + cheapest for summaries
  },

  // ── Cron ──────────────────────────────────────────────────────────────────
  // node-cron schedule string. Default = top of every hour.
  cronSchedule: process.env.CRON_SCHEDULE || '0 * * * *',

  // ── Database ──────────────────────────────────────────────────────────────
  dbPath: process.env.DB_PATH || './database/mahangapani.db',

  // ── Uploads ───────────────────────────────────────────────────────────────
  // Where article images / avatars are stored on disk
  uploadsDir: './uploads',
  maxUploadMb: 5,

  // ── Pagination ────────────────────────────────────────────────────────────
  defaultPageSize: 12,
  maxPageSize: 100,
};
