/**
 * controllers/adminController.js
 * ─────────────────────────────
 * Admin-only endpoints for the dashboard panel.
 *
 *   GET  /api/v1/admin/stats      — headline numbers for the dashboard
 *   GET  /api/v1/admin/users      — paginated user list
 *   PUT  /api/v1/admin/users/:id  — change role / activate / ban a user
 *   GET  /api/v1/admin/comments   — paginated comment list with moderation
 *   GET  /api/v1/admin/articles   — all articles (incl. unpublished drafts)
 *
 * All routes in this controller are guarded by authenticate + requireAdmin
 * in the router, so we don't re-check roles here.
 */

const { getDb } = require('../database/migrate');

// ─── stats (GET /api/v1/admin/stats) ─────────────────────────────────────────
// Returns a single object with all the numbers needed by the dashboard cards.

function getStats(req, res, next) {
  try {
    const db = getDb();

    const totalArticles  = db.prepare('SELECT COUNT(*) AS n FROM articles').get().n;
    const totalUsers     = db.prepare("SELECT COUNT(*) AS n FROM users WHERE role = 'user'").get().n;
    const totalComments  = db.prepare('SELECT COUNT(*) AS n FROM comments').get().n;
    const totalViews     = db.prepare('SELECT COALESCE(SUM(views), 0) AS n FROM articles').get().n;

    // Articles published today (UTC)
    const todayArticles = db.prepare(`
      SELECT COUNT(*) AS n FROM articles
      WHERE date(published_at) = date('now')
    `).get().n;

    // Breaking news count
    const breakingCount = db.prepare(
      'SELECT COUNT(*) AS n FROM articles WHERE is_breaking = 1 AND is_published = 1'
    ).get().n;

    // Top 5 most-viewed articles (for the dashboard chart/table)
    const topArticles = db.prepare(`
      SELECT id, title, category_slug, views, likes, published_at
      FROM articles ORDER BY views DESC LIMIT 5
    `).all();

    // Articles by category (for the pie/bar chart)
    const byCategory = db.prepare(`
      SELECT category_slug, COUNT(*) AS count
      FROM articles WHERE is_published = 1
      GROUP BY category_slug ORDER BY count DESC
    `).all();

    // Newest 5 users
    const recentUsers = db.prepare(`
      SELECT id, name, email, role, created_at FROM users
      ORDER BY created_at DESC LIMIT 5
    `).all();

    res.json({
      data: {
        totalArticles,
        totalUsers,
        totalComments,
        totalViews,
        todayArticles,
        breakingCount,
        topArticles,
        byCategory,
        recentUsers,
      },
    });
  } catch (err) {
    next(err);
  }
}

// ─── listUsers (GET /api/v1/admin/users) ─────────────────────────────────────

function listUsers(req, res, next) {
  try {
    const db    = getDb();
    const page  = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit = Math.min(100, parseInt(req.query.limit, 10) || 20);
    const offset = (page - 1) * limit;
    const search = req.query.search || '';

    const where  = search ? 'WHERE name LIKE ? OR email LIKE ?' : '';
    const params = search ? [`%${search}%`, `%${search}%`] : [];

    const users = db.prepare(`
      SELECT id, name, email, role, is_active, created_at, updated_at
      FROM users ${where}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    const total = db.prepare(`
      SELECT COUNT(*) AS n FROM users ${where}
    `).get(...params).n;

    res.json({
      data: users,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
}

// ─── updateUser (PUT /api/v1/admin/users/:id) ────────────────────────────────
// Admin can change a user's role or toggle their active status.

function updateUser(req, res, next) {
  try {
    const db = getDb();
    const { role, is_active } = req.body;
    const userId = req.params.id;

    // Prevent admin from accidentally demoting themselves
    if (parseInt(userId, 10) === req.user.id && role && role !== 'admin') {
      return res.status(400).json({ error: 'You cannot remove your own admin role.' });
    }

    const updates = [];
    const params  = [];

    if (role      !== undefined) { updates.push('role = ?');      params.push(role);      }
    if (is_active !== undefined) { updates.push('is_active = ?'); params.push(is_active ? 1 : 0); }

    if (!updates.length) return res.status(400).json({ error: 'Nothing to update.' });

    updates.push("updated_at = datetime('now')");
    params.push(userId);

    db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);

    const updated = db.prepare(
      'SELECT id, name, email, role, is_active, created_at FROM users WHERE id = ?'
    ).get(userId);

    res.json({ message: 'User updated.', data: updated });
  } catch (err) {
    next(err);
  }
}

// ─── listComments (GET /api/v1/admin/comments) ───────────────────────────────

function listComments(req, res, next) {
  try {
    const db     = getDb();
    const page   = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit  = Math.min(100, parseInt(req.query.limit, 10) || 20);
    const offset = (page - 1) * limit;

    const comments = db.prepare(`
      SELECT c.*, a.title AS article_title, u.name AS user_name
      FROM comments c
      LEFT JOIN articles a ON c.article_id = a.id
      LEFT JOIN users    u ON c.user_id    = u.id
      ORDER BY c.created_at DESC
      LIMIT ? OFFSET ?
    `).all(limit, offset);

    const total = db.prepare('SELECT COUNT(*) AS n FROM comments').get().n;

    res.json({
      data: comments,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
}

// ─── listAllArticles (GET /api/v1/admin/articles) ────────────────────────────
// Like the public news list but includes unpublished drafts.

function listAllArticles(req, res, next) {
  try {
    const db     = getDb();
    const page   = Math.max(1, parseInt(req.query.page, 10) || 1);
    const limit  = Math.min(100, parseInt(req.query.limit, 10) || 20);
    const offset = (page - 1) * limit;
    const cat    = req.query.category || '';
    const status = req.query.status;   // 'published' | 'draft' | undefined

    const wheres = [];
    const params = [];

    if (cat)             { wheres.push('category_slug = ?'); params.push(cat); }
    if (status === 'published') { wheres.push('is_published = 1'); }
    if (status === 'draft')     { wheres.push('is_published = 0'); }

    const where = wheres.length ? `WHERE ${wheres.join(' AND ')}` : '';

    const articles = db.prepare(`
      SELECT id, title, slug, category_slug, is_published, is_breaking,
             is_hot, views, likes, source, fetched_from, published_at, created_at
      FROM articles ${where}
      ORDER BY created_at DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    const total = db.prepare(`
      SELECT COUNT(*) AS n FROM articles ${where}
    `).get(...params).n;

    res.json({
      data: articles,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
}

module.exports = { getStats, listUsers, updateUser, listComments, listAllArticles };
