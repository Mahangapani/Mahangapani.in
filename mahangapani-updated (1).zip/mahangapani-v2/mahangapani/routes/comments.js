/**
 * routes/comments.js
 * ──────────────────
 * GET  /api/v1/comments/:articleId          — fetch threaded comments
 * POST /api/v1/comments/:articleId          — post a comment (guest or user)
 * DELETE /api/v1/comments/:commentId        — delete own comment (or admin any)
 * POST /api/v1/comments/:commentId/like     — like a comment
 * PATCH /api/v1/comments/:commentId/approve — admin: approve or hide a comment
 */

const router = require('express').Router();
const ctrl   = require('../controllers/commentController');
const { authenticate, requireAdmin, optionalAuth } = require('../middleware/auth');
const { commentRules } = require('../middleware/validate');

router.get('/:articleId',                    ctrl.getComments);
router.post('/:articleId', commentRules, optionalAuth, ctrl.addComment);
router.delete('/:commentId', authenticate,   ctrl.deleteComment);
router.post('/:commentId/like', optionalAuth, ctrl.likeComment);
router.patch('/:commentId/approve', authenticate, requireAdmin, ctrl.approveComment);

module.exports = router;
