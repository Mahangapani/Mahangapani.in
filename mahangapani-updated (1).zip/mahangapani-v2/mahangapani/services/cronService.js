/**
 * services/cronService.js
 * ────────────────────────
 * Schedules the automatic news-fetching pipeline using node-cron.
 *
 * Why node-cron instead of setInterval?
 *   - node-cron uses Unix cron syntax (e.g. "0 * * * *" = every hour
 *     at minute 0) which is a widely understood standard.
 *   - setInterval drifts over time; cron fires at exact clock positions.
 *   - node-cron respects the server timezone so scheduling is predictable.
 *
 * The schedule is controlled by the CRON_SCHEDULE environment variable,
 * defaulting to "0 * * * *" (once per hour). You can change it to
 * "*/30 * * * *" for every 30 minutes, etc.
 */

const cron   = require('node-cron');
const config = require('../config');
const { fetchAndStore } = require('./newsApiService');

let newsJob = null; // Reference to the scheduled task (for stopping/restarting)

/**
 * startCronJobs
 * ──────────────
 * Called once during server bootstrap. Registers the cron task and
 * immediately runs the first fetch so the DB is populated before
 * any user loads the homepage.
 */
function startCronJobs() {
  // Validate the cron expression first — node-cron will throw if invalid
  if (!cron.validate(config.cronSchedule)) {
    console.error(`[Cron] Invalid schedule expression: "${config.cronSchedule}"`);
    console.error('[Cron] Falling back to hourly schedule: "0 * * * *"');
    config.cronSchedule = '0 * * * *';
  }

  newsJob = cron.schedule(config.cronSchedule, async () => {
    console.log(`\n[Cron] ⏰ News fetch triggered — ${new Date().toISOString()}`);
    try {
      const report = await fetchAndStore();
      console.log(`[Cron] ✅ Done. Saved: ${report.saved}, Skipped: ${report.skipped}`);
    } catch (err) {
      // Cron failures should never crash the server — log and continue
      console.error('[Cron] ❌ Fetch failed:', err.message);
    }
  }, {
    scheduled: true,
    timezone: 'Asia/Kolkata', // IST — change to your target timezone
  });

  console.log(`[Cron] Scheduled news fetch: "${config.cronSchedule}" (IST)`);

  // Run immediately on startup so we have articles right away.
  // We wrap in a setTimeout to not block the server listen() call.
  setTimeout(async () => {
    console.log('[Cron] Running initial news fetch on startup…');
    try {
      await fetchAndStore();
    } catch (err) {
      console.error('[Cron] Initial fetch failed:', err.message);
    }
  }, 3000); // 3-second delay — gives the server time to fully start
}

/**
 * stopCronJobs
 * ─────────────
 * Useful for graceful shutdown or testing.
 */
function stopCronJobs() {
  if (newsJob) {
    newsJob.stop();
    newsJob = null;
    console.log('[Cron] News job stopped.');
  }
}

module.exports = { startCronJobs, stopCronJobs };
