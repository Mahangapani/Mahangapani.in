/**
 * controllers/newsController.js
 * ─────────────────────────────
 * All news-related API handlers:
 *
 *   GET  /api/v1/news               — paginated list with filters
 *   GET  /api/v1/news/search        — full-text search
 *   GET  /api/v1/news/breaking      — breaking news ticker items
 *   GET  /api/v1/news/trending      — most-viewed articles
 *   GET  /api/v1/news/:slug         — single article + view count increment
 *   POST /api/v1/news/:id/like      — toggle like on an article
 *   POST /api/v1/news               — (admin) create article
 *   PUT  /api/v1/news/:id           — (admin) update article
 *   DELETE /api/v1/news/:id         — (admin) delete article
 *   POST /api/v1/news/fetch-now     — (admin) trigger immediate NewsAPI fetch
 *
 * Pagination convention:
 *   All list endpoints accept ?page=1&limit=12 query params.
 *   Responses include { data, pagination: { page, limit, total, pages } }
 *   so the frontend can render page controls without a second request.
 */

const slugify  = require('slugify');
const config   = require('../config');
const { getDb } = require('../database/migrate');
const { fetchAndStore } = require('../services/newsApiService');
const { generateSummary, generateTags } = require('../services/aiService');

// ─── Helpers ─────────────────────────────────────────────────────────────────

function paginate(req) {
  const page  = Math.max(1, parseInt(req.query.page, 10)  || 1);
  const limit = Math.min(config.maxPageSize, parseInt(req.query.limit, 10) || config.defaultPageSize);
  const offset = (page - 1) * limit;
  return { page, limit, offset };
}

function makeSlug(title) {
  const base   = slugify(title, { lower: true, strict: true, trim: true }).slice(0, 80);
  const suffix = Date.now().toString(36).slice(-5);
  return `${base}-${suffix}`;
}

function parseArticle(row) {
  if (!row) return null;
  return {
    ...row,
    tags:        JSON.parse(row.tags || '[]'),
    is_breaking: !!row.is_breaking,
    is_hot:      !!row.is_hot,
    is_published: !!row.is_published,
  };
}

// ─── getNews (GET /api/v1/news) ───────────────────────────────────────────────
// Supports filtering by: category_slug, language, is_breaking, is_hot
// Supports sorting by: published_at (default), views, likes

function getNews(req, res, next) {
  try {
    const { page, limit, offset } = paginate(req);
    const { category, language, breaking, hot, sort = 'published_at' } = req.query;
    const db = getDb();

    // Build WHERE clauses dynamically based on which filters are present
    const wheres  = ['is_published = 1'];
    const params  = [];

    if (category) { wheres.push('category_slug = ?'); params.push(category); }
    if (language) { wheres.push('language = ?');      params.push(language); }
    if (breaking === '1') { wheres.push('is_breaking = 1'); }
    if (hot      === '1') { wheres.push('is_hot = 1');      }

    const where = wheres.join(' AND ');

    // Whitelist the sort column to prevent SQL injection
    const sortCol = ['published_at', 'views', 'likes', 'created_at'].includes(sort)
      ? sort : 'published_at';

    const articles = db.prepare(`
      SELECT * FROM articles
      WHERE ${where}
      ORDER BY ${sortCol} DESC
      LIMIT ? OFFSET ?
    `).all(...params, limit, offset);

    const total = db.prepare(`
      SELECT COUNT(*) as count FROM articles WHERE ${where}
    `).get(...params).count;

    res.json({
      data: articles.map(parseArticle),
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
}

// ─── searchNews (GET /api/v1/news/search?q=term) ─────────────────────────────
// Uses SQLite FTS5 for fast full-text search across title, summary, content, tags

function searchNews(req, res, next) {
  try {
    const { q, page: _p, limit: _l } = req.query;
    const { page, limit, offset } = paginate(req);
    const db = getDb();

    if (!q || q.trim().length < 2) {
      return res.status(400).json({ error: 'Search query must be at least 2 characters.' });
    }

    // FTS5 MATCH syntax — the * is a prefix operator (so "crick*" matches "cricket")
    const searchTerm = q.trim().replace(/['"*]/g, '') + '*';

    const articles = db.prepare(`
      SELECT a.* FROM articles a
      JOIN articles_fts f ON a.id = f.rowid
      WHERE f.articles_fts MATCH ? AND a.is_published = 1
      ORDER BY rank
      LIMIT ? OFFSET ?
    `).all(searchTerm, limit, offset);

    const total = db.prepare(`
      SELECT COUNT(*) as count FROM articles a
      JOIN articles_fts f ON a.id = f.rowid
      WHERE f.articles_fts MATCH ? AND a.is_published = 1
    `).get(searchTerm).count;

    res.json({
      data: articles.map(parseArticle),
      query: q,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
}

// ─── getBreaking (GET /api/v1/news/breaking) ─────────────────────────────────
// Returns the 10 most recent breaking news items for the ticker

function getBreaking(req, res, next) {
  try {
    const db = getDb();
    const articles = db.prepare(`
      SELECT id, title, title_hi, slug, category_slug, source, published_at
      FROM articles
      WHERE is_breaking = 1 AND is_published = 1
      ORDER BY published_at DESC
      LIMIT 10
    `).all();
    res.json({ data: articles });
  } catch (err) {
    next(err);
  }
}

// ─── getTrending (GET /api/v1/news/trending) ─────────────────────────────────
// Top 10 articles by view count in the last 7 days

function getTrending(req, res, next) {
  try {
    const db = getDb();
    const articles = db.prepare(`
      SELECT * FROM articles
      WHERE is_published = 1
        AND published_at >= datetime('now', '-7 days')
      ORDER BY views DESC
      LIMIT 10
    `).all();
    res.json({ data: articles.map(parseArticle) });
  } catch (err) {
    next(err);
  }
}

// ─── getCategories (GET /api/v1/news/categories) ─────────────────────────────

function getCategories(req, res, next) {
  try {
    const db = getDb();
    const categories = db.prepare('SELECT * FROM categories ORDER BY name').all();
    res.json({ data: categories });
  } catch (err) {
    next(err);
  }
}

// ─── getArticle (GET /api/v1/news/:slug) ─────────────────────────────────────
// Returns a single article and atomically increments its view counter

function getArticle(req, res, next) {
  try {
    const db = getDb();
    const article = db.prepare(`
      SELECT * FROM articles WHERE slug = ? AND is_published = 1
    `).get(req.params.slug);

    if (!article) {
      return res.status(404).json({ error: 'Article not found.' });
    }

    // Increment view count — using a prepared statement for performance
    db.prepare('UPDATE articles SET views = views + 1 WHERE id = ?').run(article.id);
    article.views += 1; // reflect in response without a second SELECT

    // Fetch related articles from the same category
    const related = db.prepare(`
      SELECT id, title, title_hi, slug, image_url, category_slug, source, published_at, views
      FROM articles
      WHERE category_slug = ? AND id != ? AND is_published = 1
      ORDER BY published_at DESC
      LIMIT 4
    `).all(article.category_slug, article.id);

    res.json({
      data:    parseArticle(article),
      related: related.map(parseArticle),
    });
  } catch (err) {
    next(err);
  }
}

// ─── likeArticle (POST /api/v1/news/:id/like) ────────────────────────────────
// Simple toggle: clicking again removes the like.
// In a production app you'd store likes in a pivot table; here we keep it simple.

function likeArticle(req, res, next) {
  try {
    const db = getDb();
    const article = db.prepare('SELECT id, likes FROM articles WHERE id = ?').get(req.params.id);
    if (!article) return res.status(404).json({ error: 'Article not found.' });

    db.prepare('UPDATE articles SET likes = likes + 1 WHERE id = ?').run(article.id);
    res.json({ likes: article.likes + 1 });
  } catch (err) {
    next(err);
  }
}

// ─── createArticle (POST /api/v1/news) — Admin only ──────────────────────────

async function createArticle(req, res, next) {
  try {
    const db = getDb();
    const {
      title, content, summary, image_url, source, source_url, author,
      category_slug, is_breaking = 0, is_hot = 0, is_published = 1, tags = [],
    } = req.body;

    const slug = makeSlug(title);

    // Try to AI-enhance the article if keys are configured
    let enhancedSummary   = summary || '';
    let enhancedSummaryHi = null;
    let titleHi           = null;

    try {
      const ai = await generateSummary(title, content || summary);
      enhancedSummary   = ai.summary    || summary || '';
      enhancedSummaryHi = ai.summaryHi  || null;
      titleHi           = ai.titleHi    || null;
    } catch {
      // Non-fatal — save without AI enhancement
    }

    let articleTags = tags;
    if (!articleTags.length) {
      try { articleTags = await generateTags(title, content || summary); } catch {}
    }

    const result = db.prepare(`
      INSERT INTO articles
        (title, title_hi, slug, summary, summary_hi, content, image_url,
         source, source_url, author, category_slug, is_breaking, is_hot,
         is_published, tags, language, fetched_from)
      VALUES
        (@title, @title_hi, @slug, @summary, @summary_hi, @content, @image_url,
         @source, @source_url, @author, @category_slug, @is_breaking, @is_hot,
         @is_published, @tags, @language, 'admin')
    `).run({
      title, title_hi: titleHi, slug,
      summary: enhancedSummary, summary_hi: enhancedSummaryHi,
      content: content || '',
      image_url: image_url || null,
      source: source || 'Mahangapani',
      source_url: source_url || null,
      author: author || req.user?.name || 'Staff Reporter',
      category_slug: category_slug || 'india',
      is_breaking: is_breaking ? 1 : 0,
      is_hot:      is_hot      ? 1 : 0,
      is_published: is_published ? 1 : 0,
      tags: JSON.stringify(articleTags),
      language: req.body.language || 'en',
    });

    const created = db.prepare('SELECT * FROM articles WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json({ message: 'Article created.', data: parseArticle(created) });
  } catch (err) {
    next(err);
  }
}

// ─── updateArticle (PUT /api/v1/news/:id) — Admin only ───────────────────────

async function updateArticle(req, res, next) {
  try {
    const db = getDb();
    const existing = db.prepare('SELECT id FROM articles WHERE id = ?').get(req.params.id);
    if (!existing) return res.status(404).json({ error: 'Article not found.' });

    const fields = {};
    const allowed = [
      'title','title_hi','summary','summary_hi','content','image_url',
      'source','source_url','author','category_slug','is_breaking',
      'is_hot','is_published','language',
    ];
    for (const key of allowed) {
      if (req.body[key] !== undefined) fields[key] = req.body[key];
    }
    if (req.body.tags) fields.tags = JSON.stringify(req.body.tags);
    fields.updated_at = "datetime('now')"; // will be handled literally

    const setClauses = Object.keys(fields)
      .filter(k => k !== 'updated_at')
      .map(k => `${k} = @${k}`)
      .join(', ');

    db.prepare(`
      UPDATE articles
      SET ${setClauses}, updated_at = datetime('now')
      WHERE id = @id
    `).run({ ...fields, id: req.params.id });

    const updated = db.prepare('SELECT * FROM articles WHERE id = ?').get(req.params.id);
    res.json({ message: 'Article updated.', data: parseArticle(updated) });
  } catch (err) {
    next(err);
  }
}

// ─── deleteArticle (DELETE /api/v1/news/:id) — Admin only ────────────────────

function deleteArticle(req, res, next) {
  try {
    const db = getDb();
    const result = db.prepare('DELETE FROM articles WHERE id = ?').run(req.params.id);
    if (!result.changes) return res.status(404).json({ error: 'Article not found.' });
    res.json({ message: 'Article deleted.' });
  } catch (err) {
    next(err);
  }
}

// ─── fetchNow (POST /api/v1/news/fetch-now) — Admin only ─────────────────────
// Triggers a manual news fetch without waiting for the next cron tick.
// Useful when the admin wants fresh news on demand.

async function fetchNow(req, res, next) {
  try {
    const report = await fetchAndStore();
    res.json({
      message: 'News fetch completed.',
      report,
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getNews, searchNews, getBreaking, getTrending, getCategories,
  getArticle, likeArticle, createArticle, updateArticle, deleteArticle, fetchNow,
};
