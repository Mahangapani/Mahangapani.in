/**
 * middleware/validate.js
 * ──────────────────────
 * Centralises all express-validator rule sets so route files stay
 * thin. Each export is an array of validation rules + a final
 * "handleValidationErrors" middleware that short-circuits with a
 * 400 if any rule failed.
 *
 * Why centralise? Because if validation changes (e.g., password
 * minimum length), you update one place instead of hunting through
 * every route file.
 */

const { body, param, query, validationResult } = require('express-validator');

// Called as the last item in every validation array.
// If there are errors, it returns them all at once (not just the first).
function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: 'Validation failed',
      details: errors.array().map(e => ({ field: e.path, message: e.msg })),
    });
  }
  next();
}

// ─── Auth validations ────────────────────────────────────────────────────────

const registerRules = [
  body('name')
    .trim().notEmpty().withMessage('Name is required')
    .isLength({ min: 2, max: 60 }).withMessage('Name must be 2–60 characters'),
  body('email')
    .trim().normalizeEmail()
    .isEmail().withMessage('Valid email required'),
  body('password')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters')
    .matches(/[A-Z]/).withMessage('Password must contain an uppercase letter')
    .matches(/[0-9]/).withMessage('Password must contain a number'),
  handleValidationErrors,
];

const loginRules = [
  body('email').trim().normalizeEmail().isEmail().withMessage('Valid email required'),
  body('password').notEmpty().withMessage('Password required'),
  handleValidationErrors,
];

// ─── Article validations ─────────────────────────────────────────────────────

const articleRules = [
  body('title').trim().notEmpty().withMessage('Title is required')
    .isLength({ max: 300 }).withMessage('Title max 300 chars'),
  body('category_slug').trim().notEmpty().withMessage('Category is required'),
  body('summary').optional().isLength({ max: 1000 }).withMessage('Summary max 1000 chars'),
  body('content').optional().isLength({ max: 50000 }).withMessage('Content too long'),
  body('is_breaking').optional().isBoolean().toBoolean(),
  body('is_hot').optional().isBoolean().toBoolean(),
  body('is_published').optional().isBoolean().toBoolean(),
  handleValidationErrors,
];

// ─── Comment validations ─────────────────────────────────────────────────────

const commentRules = [
  param('articleId').isInt({ gt: 0 }).withMessage('Invalid article ID'),
  body('body').trim().notEmpty().withMessage('Comment body required')
    .isLength({ min: 2, max: 2000 }).withMessage('Comment must be 2–2000 characters'),
  body('guest_name').optional().trim().isLength({ max: 80 }),
  body('guest_email').optional().trim().normalizeEmail().isEmail().withMessage('Valid email required'),
  handleValidationErrors,
];

// ─── Query validations ───────────────────────────────────────────────────────

const paginationRules = [
  query('page').optional().isInt({ gt: 0 }).toInt().withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ gt: 0, lt: 101 }).toInt().withMessage('Limit must be 1–100'),
  handleValidationErrors,
];

module.exports = {
  handleValidationErrors,
  registerRules,
  loginRules,
  articleRules,
  commentRules,
  paginationRules,
};
