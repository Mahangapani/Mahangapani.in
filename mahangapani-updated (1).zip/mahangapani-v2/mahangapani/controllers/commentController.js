/**
 * controllers/commentController.js
 * ─────────────────────────────────
 * Handles threaded commenting on articles.
 *
 * Architecture note — threading:
 *   Comments can have a parent_id so they form a two-level tree
 *   (top-level comment → replies). We query them in two passes:
 *   1. Fetch all top-level comments (parent_id IS NULL)
 *   2. Fetch all replies and attach them to their parent in memory
 *   This avoids a recursive SQL CTE (which SQLite supports but is
 *   overkill for two levels) and keeps the query simple.
 *
 * Guest commenting:
 *   Users don't have to be logged in to comment. If no JWT is
 *   present, we require guest_name (and optionally guest_email).
 *   If a JWT IS present, we ignore guest_name and use the user account.
 */

const { getDb } = require('../database/migrate');

// ─── getComments (GET /api/v1/comments/:articleId) ───────────────────────────
// Returns all approved comments for an article, with replies nested
// under their parent comment.

function getComments(req, res, next) {
  try {
    const db        = getDb();
    const articleId = parseInt(req.params.articleId, 10);

    // Confirm the article exists first
    const article = db.prepare('SELECT id FROM articles WHERE id = ?').get(articleId);
    if (!article) return res.status(404).json({ error: 'Article not found.' });

    // Join with users table to get the commenter's name + avatar
    const allComments = db.prepare(`
      SELECT
        c.*,
        u.name    AS user_name,
        u.avatar  AS user_avatar,
        u.role    AS user_role
      FROM comments c
      LEFT JOIN users u ON c.user_id = u.id
      WHERE c.article_id = ? AND c.is_approved = 1
      ORDER BY c.created_at ASC
    `).all(articleId);

    // Build the tree: top-level comments carry a 'replies' array
    const topLevel = [];
    const byId     = {};

    for (const c of allComments) {
      c.replies = [];
      // Display name: prefer logged-in user's name, fall back to guest_name
      c.display_name  = c.user_name  || c.guest_name  || 'Anonymous';
      c.display_avatar = c.user_avatar || null;
      byId[c.id] = c;
    }

    for (const c of allComments) {
      if (c.parent_id && byId[c.parent_id]) {
        byId[c.parent_id].replies.push(c);
      } else {
        topLevel.push(c);
      }
    }

    res.json({ data: topLevel, total: allComments.length });
  } catch (err) {
    next(err);
  }
}

// ─── addComment (POST /api/v1/comments/:articleId) ───────────────────────────
// Creates a new comment. Works for both authenticated users and guests.

function addComment(req, res, next) {
  try {
    const db        = getDb();
    const articleId = parseInt(req.params.articleId, 10);
    const { body, parent_id, guest_name, guest_email } = req.body;

    // Must have either a logged-in user or a guest name
    if (!req.user && !guest_name?.trim()) {
      return res.status(400).json({
        error: 'Please provide your name to comment as a guest, or log in.',
      });
    }

    const article = db.prepare('SELECT id FROM articles WHERE id = ?').get(articleId);
    if (!article) return res.status(404).json({ error: 'Article not found.' });

    // If parent_id given, confirm it belongs to the same article
    if (parent_id) {
      const parent = db.prepare(
        'SELECT id FROM comments WHERE id = ? AND article_id = ?'
      ).get(parent_id, articleId);
      if (!parent) return res.status(400).json({ error: 'Invalid parent comment.' });
    }

    const result = db.prepare(`
      INSERT INTO comments
        (article_id, user_id, parent_id, guest_name, guest_email, body, is_approved)
      VALUES (?, ?, ?, ?, ?, ?, 1)
    `).run(
      articleId,
      req.user?.id    || null,
      parent_id       || null,
      req.user ? null : (guest_name?.trim() || null),
      req.user ? null : (guest_email?.trim() || null),
      body.trim()
    );

    const comment = db.prepare(`
      SELECT c.*, u.name AS user_name, u.avatar AS user_avatar
      FROM comments c LEFT JOIN users u ON c.user_id = u.id
      WHERE c.id = ?
    `).get(result.lastInsertRowid);

    comment.display_name = comment.user_name || comment.guest_name || 'Anonymous';
    comment.replies      = [];

    res.status(201).json({ message: 'Comment added.', data: comment });
  } catch (err) {
    next(err);
  }
}

// ─── deleteComment (DELETE /api/v1/comments/:commentId) ──────────────────────
// Users can delete their own comments; admins can delete any.

function deleteComment(req, res, next) {
  try {
    const db      = getDb();
    const comment = db.prepare('SELECT * FROM comments WHERE id = ?').get(req.params.commentId);

    if (!comment) return res.status(404).json({ error: 'Comment not found.' });

    const isOwner = req.user?.id === comment.user_id;
    const isAdmin = req.user?.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ error: 'You can only delete your own comments.' });
    }

    // Cascade delete will remove child replies too (FK ON DELETE CASCADE)
    db.prepare('DELETE FROM comments WHERE id = ?').run(comment.id);
    res.json({ message: 'Comment deleted.' });
  } catch (err) {
    next(err);
  }
}

// ─── likeComment (POST /api/v1/comments/:commentId/like) ─────────────────────

function likeComment(req, res, next) {
  try {
    const db      = getDb();
    const comment = db.prepare('SELECT id, likes FROM comments WHERE id = ?').get(req.params.commentId);
    if (!comment) return res.status(404).json({ error: 'Comment not found.' });

    db.prepare('UPDATE comments SET likes = likes + 1 WHERE id = ?').run(comment.id);
    res.json({ likes: comment.likes + 1 });
  } catch (err) {
    next(err);
  }
}

// ─── approveComment (PATCH /api/v1/comments/:commentId/approve) — Admin ──────

function approveComment(req, res, next) {
  try {
    const db = getDb();
    const { approved } = req.body;
    db.prepare('UPDATE comments SET is_approved = ? WHERE id = ?')
      .run(approved ? 1 : 0, req.params.commentId);
    res.json({ message: `Comment ${approved ? 'approved' : 'hidden'}.` });
  } catch (err) {
    next(err);
  }
}

module.exports = { getComments, addComment, deleteComment, likeComment, approveComment };
