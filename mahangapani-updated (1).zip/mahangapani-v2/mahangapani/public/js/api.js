/**
 * public/js/api.js
 * ────────────────
 * This is the bridge between your HTML frontend and the Node.js backend.
 * Every time the frontend needs data (news articles, user login, comments),
 * it calls a function from this file — never talks to the server directly.
 *
 * Why centralise all API calls here?
 *   1. The base URL is defined once. If the server moves, you change one line.
 *   2. The auth token is attached automatically to every request.
 *   3. Error handling (401 redirect, JSON parsing) is in one place.
 *   4. It reads like documentation — the function names tell you exactly
 *      what the backend can do.
 */

const API_BASE = '/api/v1';

// ─── Core fetch wrapper ───────────────────────────────────────────────────────
// Every public function below ultimately calls this. It handles:
//   - Attaching the JWT token from localStorage
//   - Serialising/deserialising JSON
//   - Redirecting to home if the server returns 401 (token expired)
//   - Throwing meaningful Error objects so callers can catch them

async function apiFetch(endpoint, options = {}) {
  const token = localStorage.getItem('mg_token');

  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const response = await fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
  });

  // Parse the JSON body regardless of the status code
  let data;
  try {
    data = await response.json();
  } catch {
    throw new Error('Server returned an unexpected response format.');
  }

  // 401 means the JWT expired or was tampered with. Clear local state
  // and bounce the user back to the homepage gracefully.
  if (response.status === 401) {
    localStorage.removeItem('mg_token');
    localStorage.removeItem('mg_user');
    window.location.reload();
    return;
  }

  // For any non-2xx response, throw so the caller's catch block fires
  if (!response.ok) {
    throw new Error(data.error || `Request failed with status ${response.status}`);
  }

  return data;
}

// ─── News API ─────────────────────────────────────────────────────────────────

const NewsAPI = {

  /**
   * getAll — fetches a paginated list of articles.
   * @param {Object} params  e.g. { category: 'sports', page: 2, limit: 12 }
   */
  getAll(params = {}) {
    const qs = new URLSearchParams(params).toString();
    return apiFetch(`/news?${qs}`);
  },

  /** getOne — fetches a single article by its URL slug. */
  getOne(slug) {
    return apiFetch(`/news/${slug}`);
  },

  /** search — full-text search across title, summary, content, tags. */
  search(query, page = 1) {
    return apiFetch(`/news/search?q=${encodeURIComponent(query)}&page=${page}`);
  },

  /** getBreaking — returns the ticker items (id, title, slug only). */
  getBreaking() {
    return apiFetch('/news/breaking');
  },

  /** getTrending — top 10 by view count in the last 7 days. */
  getTrending() {
    return apiFetch('/news/trending');
  },

  /** getCategories — returns all category rows from the DB. */
  getCategories() {
    return apiFetch('/news/categories');
  },

  /** like — increments the like counter on an article. */
  like(articleId) {
    return apiFetch(`/news/${articleId}/like`, { method: 'POST' });
  },

  // ── Admin write operations ──────────────────────────────────────────────────

  create(articleData) {
    return apiFetch('/news', { method: 'POST', body: JSON.stringify(articleData) });
  },

  update(id, articleData) {
    return apiFetch(`/news/${id}`, { method: 'PUT', body: JSON.stringify(articleData) });
  },

  delete(id) {
    return apiFetch(`/news/${id}`, { method: 'DELETE' });
  },

  /** fetchNow — tells the server to immediately pull fresh news from NewsAPI. */
  fetchNow() {
    return apiFetch('/news/fetch-now', { method: 'POST' });
  },
};

// ─── Auth API ─────────────────────────────────────────────────────────────────

const AuthAPI = {

  register(name, email, password) {
    return apiFetch('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
  },

  login(email, password) {
    return apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
  },

  me() {
    return apiFetch('/auth/me');
  },

  updateProfile(data) {
    return apiFetch('/auth/profile', { method: 'PUT', body: JSON.stringify(data) });
  },

  changePassword(currentPassword, newPassword) {
    return apiFetch('/auth/password', {
      method: 'PUT',
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },
};

// ─── Comments API ─────────────────────────────────────────────────────────────

const CommentsAPI = {

  getAll(articleId) {
    return apiFetch(`/comments/${articleId}`);
  },

  add(articleId, body, parentId = null, guestName = null, guestEmail = null) {
    return apiFetch(`/comments/${articleId}`, {
      method: 'POST',
      body: JSON.stringify({ body, parent_id: parentId, guest_name: guestName, guest_email: guestEmail }),
    });
  },

  delete(commentId) {
    return apiFetch(`/comments/${commentId}`, { method: 'DELETE' });
  },

  like(commentId) {
    return apiFetch(`/comments/${commentId}/like`, { method: 'POST' });
  },
};

// ─── Admin API ────────────────────────────────────────────────────────────────

const AdminAPI = {
  getStats()           { return apiFetch('/admin/stats'); },
  listUsers(params)    { return apiFetch(`/admin/users?${new URLSearchParams(params)}`); },
  updateUser(id, data) { return apiFetch(`/admin/users/${id}`, { method: 'PUT', body: JSON.stringify(data) }); },
  listComments(params) { return apiFetch(`/admin/comments?${new URLSearchParams(params)}`); },
  listArticles(params) { return apiFetch(`/admin/articles?${new URLSearchParams(params)}`); },
};

// ─── Session helpers ──────────────────────────────────────────────────────────
// Thin wrappers around localStorage so the rest of the frontend code
// never has to know the key names or parsing logic.

const Session = {
  save(token, user) {
    localStorage.setItem('mg_token', token);
    localStorage.setItem('mg_user',  JSON.stringify(user));
  },
  clear() {
    localStorage.removeItem('mg_token');
    localStorage.removeItem('mg_user');
  },
  getUser() {
    try { return JSON.parse(localStorage.getItem('mg_user') || 'null'); }
    catch { return null; }
  },
  getToken() { return localStorage.getItem('mg_token'); },
  isLoggedIn() { return !!localStorage.getItem('mg_token'); },
  isAdmin() { return Session.getUser()?.role === 'admin'; },
};

// ─── Toast notification helper ────────────────────────────────────────────────
// Shows a small pop-up message at the bottom of the screen.
// type can be 'success', 'error', or 'info'.

function showToast(message, type = 'success') {
  const existing = document.getElementById('mg-toast');
  if (existing) existing.remove();

  const colors = { success: '#00C49A', error: '#E8001A', info: '#00A3E0' };
  const toast   = document.createElement('div');
  toast.id      = 'mg-toast';
  toast.textContent = message;
  Object.assign(toast.style, {
    position:    'fixed',
    bottom:      '24px',
    left:        '50%',
    transform:   'translateX(-50%)',
    background:  colors[type] || colors.info,
    color:       '#fff',
    padding:     '12px 24px',
    borderRadius: '8px',
    fontWeight:  '700',
    fontSize:    '13px',
    zIndex:      '9999',
    boxShadow:   '0 8px 24px rgba(0,0,0,.35)',
    animation:   'fadeUp .3s ease',
    maxWidth:    '90vw',
    textAlign:   'center',
  });

  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}

// Make everything available globally so the HTML inline scripts
// and other JS files can call them without module imports.
window.NewsAPI    = NewsAPI;
window.AuthAPI    = AuthAPI;
window.CommentsAPI = CommentsAPI;
window.AdminAPI   = AdminAPI;
window.Session    = Session;
window.showToast  = showToast;
