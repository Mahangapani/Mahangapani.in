/**
 * services/newsApiService.js
 * ──────────────────────────
 * Handles all communication with the NewsAPI.org REST API.
 *
 * Design decisions:
 *  - We keep NewsAPI concerns (URLs, headers, query params) fully
 *    inside this file so controllers never import axios directly.
 *    If we ever switch provider, we only touch this one file.
 *  - fetchAndStore() deduplicates via the article URL so running
 *    the cron job every hour never creates duplicate DB rows.
 *  - Each fetched article is immediately passed to aiService for
 *    an AI-generated summary before being saved.
 */

const axios    = require('axios');
const slugify  = require('slugify');
const config   = require('../config');
const { getDb } = require('../database/migrate');
const { generateSummary } = require('./aiService');

// Map NewsAPI category names to our internal slugs
const CATEGORY_MAP = {
  general:       'india',
  business:      'business',
  technology:    'tech',
  sports:        'sports',
  entertainment: 'entertainment',
  health:        'health',
  science:       'science',
};

// The 8 newsAPI categories we pull on every cron run
const CATEGORIES_TO_FETCH = Object.keys(CATEGORY_MAP);

/**
 * fetchHeadlines
 * Fetches the top headlines for one category from NewsAPI.
 * Returns an array of raw NewsAPI article objects.
 */
async function fetchHeadlines(category = 'general') {
  if (!config.newsApi.key) {
    console.warn('[NewsAPI] No API key configured — skipping fetch');
    return [];
  }

  const { data } = await axios.get(`${config.newsApi.baseUrl}/top-headlines`, {
    params: {
      apiKey:   config.newsApi.key,
      country:  config.newsApi.country,
      category,
      pageSize: config.newsApi.pageSize,
    },
    timeout: 10000, // 10s timeout so a slow response doesn't block the server
  });

  return data.articles || [];
}

/**
 * makeSlug
 * Converts a news title to a unique URL-safe slug.
 * Appends a short timestamp hash to handle identical headlines.
 *
 * Example: "IPL 2026 Schedule Announced" → "ipl-2026-schedule-announced-k3f8"
 */
function makeSlug(title) {
  const base = slugify(title, { lower: true, strict: true, trim: true })
    .slice(0, 80); // keep slugs reasonably short
  const suffix = Date.now().toString(36).slice(-4); // e.g. "k3f8"
  return `${base}-${suffix}`;
}

/**
 * mapArticle
 * Transforms a raw NewsAPI article object into our DB schema shape.
 * The caller is responsible for adding AI-generated fields afterward.
 */
function mapArticle(raw, categorySlug) {
  return {
    title:        raw.title     || 'Untitled',
    slug:         makeSlug(raw.title || 'untitled'),
    summary:      raw.description || '',
    content:      raw.content   || raw.description || '',
    image_url:    raw.urlToImage || null,
    source:       raw.source?.name || 'Unknown',
    source_url:   raw.url || null,
    author:       raw.author || raw.source?.name || 'Staff Reporter',
    category_slug: categorySlug,
    language:     'en',
    fetched_from: 'newsapi',
    published_at: raw.publishedAt
      ? new Date(raw.publishedAt).toISOString().replace('T', ' ').slice(0, 19)
      : new Date().toISOString().replace('T', ' ').slice(0, 19),
    tags:         JSON.stringify([categorySlug]),
    is_breaking:  0,
    is_hot:       0,
    is_published: 1,
  };
}

/**
 * saveArticle
 * Inserts one article into the DB. Uses INSERT OR IGNORE on the
 * source_url column so duplicates are silently skipped.
 * Returns the inserted row's id, or null if it was a duplicate.
 */
function saveArticle(db, article) {
  // Check for duplicate by source URL first
  if (article.source_url) {
    const existing = db
      .prepare('SELECT id FROM articles WHERE source_url = ?')
      .get(article.source_url);
    if (existing) return null; // already in the DB
  }

  const stmt = db.prepare(`
    INSERT INTO articles
      (title, title_hi, slug, summary, summary_hi, content, image_url,
       source, source_url, author, category_slug, is_breaking, is_hot,
       is_published, tags, language, fetched_from, published_at)
    VALUES
      (@title, @title_hi, @slug, @summary, @summary_hi, @content, @image_url,
       @source, @source_url, @author, @category_slug, @is_breaking, @is_hot,
       @is_published, @tags, @language, @fetched_from, @published_at)
  `);

  const result = stmt.run(article);
  return result.lastInsertRowid;
}

/**
 * fetchAndStore  ← the main entry point called by the cron job
 * ─────────────────────────────────────────────────────────────
 * 1. Iterates over all categories
 * 2. Fetches headlines from NewsAPI for each
 * 3. Generates AI summaries for new articles
 * 4. Saves non-duplicate articles to the DB
 * 5. Returns a summary report { total, saved, skipped }
 */
async function fetchAndStore() {
  const db = getDb();
  let totalFetched = 0;
  let totalSaved   = 0;
  let totalSkipped = 0;

  console.log(`[NewsAPI] Starting fetch run — ${new Date().toLocaleTimeString()}`);

  for (const category of CATEGORIES_TO_FETCH) {
    try {
      const rawArticles = await fetchHeadlines(category);
      const categorySlug = CATEGORY_MAP[category];
      totalFetched += rawArticles.length;

      for (const raw of rawArticles) {
        // Skip articles with placeholder "[Removed]" titles
        if (!raw.title || raw.title === '[Removed]') {
          totalSkipped++;
          continue;
        }

        const article = mapArticle(raw, categorySlug);

        // Attempt AI enhancement (non-blocking — failure just means no summary)
        try {
          const ai = await generateSummary(article.title, article.content || article.summary);
          article.summary    = ai.summary    || article.summary;
          article.summary_hi = ai.summaryHi  || null;
          article.title_hi   = ai.titleHi    || null;
          // Mark first 3 articles per category as "hot"
          if (totalSaved < 3) article.is_hot = 1;
        } catch (aiErr) {
          // AI failure is non-fatal — save article with original description
          console.warn('[AI] Enhancement failed for:', article.title, aiErr.message);
        }

        const insertedId = saveArticle(db, article);
        if (insertedId) {
          totalSaved++;
          console.log(`[NewsAPI] ✅ Saved [${categorySlug}]: ${article.title.slice(0, 60)}`);
        } else {
          totalSkipped++;
        }
      }

      // Small delay between categories to be polite to the API
      await new Promise(r => setTimeout(r, 500));

    } catch (err) {
      console.error(`[NewsAPI] ❌ Error fetching category "${category}":`, err.message);
    }
  }

  const report = { total: totalFetched, saved: totalSaved, skipped: totalSkipped };
  console.log('[NewsAPI] Fetch complete:', report);
  return report;
}

module.exports = { fetchAndStore, fetchHeadlines };
