/**
 * middleware/auth.js
 * ──────────────────
 * Provides two Express middleware functions:
 *
 *  authenticate  – verifies a JWT from the Authorization header.
 *                  Attaches req.user = { id, email, role } on success.
 *                  Returns 401 if the token is missing or invalid.
 *
 *  requireAdmin  – must be used AFTER authenticate.
 *                  Returns 403 if the caller is not an admin.
 *
 * Usage in routes:
 *   router.get('/secret', authenticate, handler);
 *   router.delete('/user/:id', authenticate, requireAdmin, handler);
 */

const jwt    = require('jsonwebtoken');
const config = require('../config');
const { getDb } = require('../database/migrate');

/**
 * authenticate
 * Extracts the Bearer token from the Authorization header, verifies it,
 * then confirms the user still exists and is active in the DB.
 * Attaching the user to req lets every downstream handler know who called.
 */
async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No token provided. Please log in.' });
    }

    const token = authHeader.slice(7); // strip "Bearer "
    let payload;
    try {
      payload = jwt.verify(token, config.jwt.secret);
    } catch {
      return res.status(401).json({ error: 'Invalid or expired token.' });
    }

    // Revalidate against the DB — catches deleted/banned users
    const user = getDb()
      .prepare('SELECT id, name, email, role, is_active FROM users WHERE id = ?')
      .get(payload.id);

    if (!user || !user.is_active) {
      return res.status(401).json({ error: 'Account not found or deactivated.' });
    }

    req.user = user; // { id, name, email, role, is_active }
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * requireAdmin
 * Must be placed after authenticate in the middleware chain.
 * Blocks non-admin callers with a 403 Forbidden.
 */
function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }
  next();
}

/**
 * optionalAuth
 * Like authenticate but does NOT fail when no token is present.
 * Useful for endpoints that behave differently for logged-in users
 * (e.g., marking a comment as "yours") but still work anonymously.
 */
function optionalAuth(req, _res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next(); // just continue without a user
  }
  const token = authHeader.slice(7);
  try {
    const payload = jwt.verify(token, config.jwt.secret);
    req.user = getDb()
      .prepare('SELECT id, name, email, role, is_active FROM users WHERE id = ?')
      .get(payload.id);
  } catch {
    // bad token → ignore silently, req.user stays undefined
  }
  next();
}

module.exports = { authenticate, requireAdmin, optionalAuth };
