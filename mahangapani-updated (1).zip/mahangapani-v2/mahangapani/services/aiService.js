/**
 * services/aiService.js
 * ─────────────────────
 * Provides AI-powered text enhancements for news articles using
 * the Anthropic Claude API.
 *
 * What it does:
 *  - generateSummary: takes a raw title + content and returns a
 *    polished English summary, a Hindi summary, and a Hindi headline.
 *    This powers the "AI Headlines" feature visible in the frontend.
 *
 *  - generateTags: extracts relevant topic tags from an article.
 *
 * Design note: Both functions gracefully return empty/null values
 * if the API key isn't configured or the call fails. This means the
 * news fetching pipeline never breaks just because AI is unavailable.
 */

const axios  = require('axios');
const config = require('../config');

const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';

/**
 * callClaude
 * Low-level wrapper around the Anthropic messages endpoint.
 * Extracts the first text block from the response content array.
 */
async function callClaude(systemPrompt, userMessage, maxTokens = 400) {
  if (!config.anthropic.apiKey) {
    throw new Error('ANTHROPIC_API_KEY not configured');
  }

  const response = await axios.post(
    ANTHROPIC_URL,
    {
      model:      config.anthropic.model,
      max_tokens: maxTokens,
      system:     systemPrompt,
      messages:   [{ role: 'user', content: userMessage }],
    },
    {
      headers: {
        'Content-Type':      'application/json',
        'x-api-key':         config.anthropic.apiKey,
        'anthropic-version': '2023-06-01',
      },
      timeout: 20000, // 20s — Claude is usually fast but give it room
    }
  );

  // The API returns content as an array of typed blocks; we want the text one
  const textBlock = response.data.content?.find(b => b.type === 'text');
  return textBlock?.text || '';
}

/**
 * generateSummary
 * ────────────────
 * Given a news article title and body text, returns:
 *   { summary, summaryHi, titleHi }
 *
 * All three values are optional — if parsing fails we return nulls
 * so the caller can still save the article with its original text.
 *
 * We ask Claude to return JSON because it's easy to parse reliably
 * and avoids fragile regex on free-form prose output.
 */
async function generateSummary(title, content) {
  const system = `You are a senior Indian news editor for Mahangapani, a bilingual (Hindi/English) news portal.
Your job is to create concise, accurate article summaries.
ALWAYS respond with valid JSON only — no markdown fences, no explanation.`;

  const user = `Given this news article:
TITLE: ${title}
CONTENT: ${(content || '').slice(0, 2000)}

Return a JSON object with exactly these fields:
{
  "summary":   "2-sentence plain English summary (max 200 chars)",
  "summaryHi": "2-sentence Hindi summary (max 200 chars)",
  "titleHi":   "Hindi translation of the title (max 80 chars)"
}`;

  try {
    const raw = await callClaude(system, user, 300);

    // Strip any accidental markdown fences just in case
    const cleaned = raw.replace(/```json|```/g, '').trim();
    const parsed  = JSON.parse(cleaned);

    return {
      summary:   parsed.summary   || null,
      summaryHi: parsed.summaryHi || null,
      titleHi:   parsed.titleHi   || null,
    };
  } catch (err) {
    console.warn('[AI] generateSummary failed:', err.message);
    return { summary: null, summaryHi: null, titleHi: null };
  }
}

/**
 * generateTags
 * ─────────────
 * Extracts up to 5 relevant topic tags from an article.
 * Returns a string[] — empty array on any failure.
 *
 * Example output: ["IPL", "Cricket", "BCCI", "Sports", "India"]
 */
async function generateTags(title, content) {
  const system = `You are a news categorization system.
Always respond with a JSON array of strings only. No explanation, no markdown.`;

  const user = `Extract 3–5 concise topic tags from this news article.
Return a JSON array like: ["tag1", "tag2", "tag3"]

TITLE: ${title}
CONTENT: ${(content || '').slice(0, 1000)}`;

  try {
    const raw    = await callClaude(system, user, 100);
    const cleaned = raw.replace(/```json|```/g, '').trim();
    const tags   = JSON.parse(cleaned);
    // Safety: filter out anything that isn't a short string
    return Array.isArray(tags)
      ? tags.filter(t => typeof t === 'string' && t.length < 50)
      : [];
  } catch {
    return [];
  }
}

/**
 * generateChatResponse
 * ─────────────────────
 * Powers the AI Chat widget on the frontend.
 * Returns a conversational Hindi/English answer about news topics.
 */
async function generateChatResponse(userMessage, conversationHistory = []) {
  const system = `You are Cysmiq AI — a sharp, bilingual (Hindi/English) news assistant for the Mahangapani news portal.
Answer in the same language the user writes in. Be concise (max 80 words). Be factual and helpful.
Current date: ${new Date().toLocaleDateString('en-IN')}.`;

  // Build the conversation array from history + new message
  const messages = [
    ...conversationHistory.slice(-6), // keep last 6 turns for context
    { role: 'user', content: userMessage },
  ];

  if (!config.anthropic.apiKey) {
    return 'AI chat is not configured yet. Please add your ANTHROPIC_API_KEY to the .env file.';
  }

  try {
    const response = await axios.post(
      ANTHROPIC_URL,
      {
        model:      config.anthropic.model,
        max_tokens: 300,
        system,
        messages,
      },
      {
        headers: {
          'Content-Type':      'application/json',
          'x-api-key':         config.anthropic.apiKey,
          'anthropic-version': '2023-06-01',
        },
        timeout: 15000,
      }
    );

    const textBlock = response.data.content?.find(b => b.type === 'text');
    return textBlock?.text || 'Sorry, I could not generate a response.';
  } catch (err) {
    console.error('[AI] Chat error:', err.message);
    return 'Sorry, the AI assistant is temporarily unavailable.';
  }
}

module.exports = { generateSummary, generateTags, generateChatResponse };
