/**
 * routes/news.js
 * ──────────────
 * Public news endpoints + admin-protected write endpoints.
 *
 * Public (no auth needed):
 *   GET  /api/v1/news
 *   GET  /api/v1/news/search
 *   GET  /api/v1/news/breaking
 *   GET  /api/v1/news/trending
 *   GET  /api/v1/news/categories
 *   GET  /api/v1/news/:slug
 *   POST /api/v1/news/:id/like        (optionalAuth — anyone can like)
 *
 * Admin only:
 *   POST   /api/v1/news               — create article
 *   PUT    /api/v1/news/:id           — update article
 *   DELETE /api/v1/news/:id           — delete article
 *   POST   /api/v1/news/fetch-now     — trigger manual NewsAPI fetch
 *
 * IMPORTANT: Static sub-paths (/search, /breaking, etc.) must be declared
 * BEFORE the dynamic /:slug route, otherwise Express will treat "search"
 * as a slug value and hit the wrong handler.
 */

const router = require('express').Router();
const ctrl   = require('../controllers/newsController');
const { authenticate, requireAdmin, optionalAuth } = require('../middleware/auth');
const { articleRules, paginationRules } = require('../middleware/validate');

// ── Public ────────────────────────────────────────────────────────────────────
router.get('/',            paginationRules, ctrl.getNews);
router.get('/search',      paginationRules, ctrl.searchNews);
router.get('/breaking',                    ctrl.getBreaking);
router.get('/trending',                    ctrl.getTrending);
router.get('/categories',                  ctrl.getCategories);

// ── Article detail + interactions ─────────────────────────────────────────────
router.get('/:slug',               ctrl.getArticle);
router.post('/:id/like', optionalAuth, ctrl.likeArticle);

// ── Admin: write operations ───────────────────────────────────────────────────
router.post('/',         authenticate, requireAdmin, articleRules, ctrl.createArticle);
router.put('/:id',       authenticate, requireAdmin, articleRules, ctrl.updateArticle);
router.delete('/:id',    authenticate, requireAdmin,               ctrl.deleteArticle);
router.post('/fetch-now', authenticate, requireAdmin,              ctrl.fetchNow);

module.exports = router;
