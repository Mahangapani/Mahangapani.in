/**
 * database/migrate.js
 * ───────────────────
 * Creates all SQLite tables on first boot. Safe to re-run — uses
 * "IF NOT EXISTS" everywhere so existing data is never wiped.
 *
 * Why SQLite? Zero configuration, single file, works on any host
 * (Replit, Railway, VPS). Swap to Postgres later by just swapping
 * the DB adapter — the controller code stays identical.
 */

require('dotenv').config();
const Database = require('better-sqlite3');
const path     = require('path');
const bcrypt   = require('bcryptjs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'mahangapani.db');

let _db = null; // singleton connection — opened once, reused everywhere

function getDb() {
  if (!_db) {
    _db = new Database(DB_PATH);
    // WAL mode → readers don't block writers; much better concurrency
    _db.pragma('journal_mode = WAL');
    // SQLite ignores foreign keys unless you explicitly turn this on
    _db.pragma('foreign_keys = ON');
  }
  return _db;
}

function initDatabase() {
  const db = getDb();

  // ── users ──────────────────────────────────────────────────────────────────
  // Stores both regular readers (role='user') and editors/admins (role='admin')
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT    NOT NULL,
      email      TEXT    NOT NULL UNIQUE,
      password   TEXT    NOT NULL,
      role       TEXT    NOT NULL DEFAULT 'user',
      avatar     TEXT,
      bio        TEXT,
      is_active  INTEGER NOT NULL DEFAULT 1,
      created_at TEXT    NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT    NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // ── categories ─────────────────────────────────────────────────────────────
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      name       TEXT NOT NULL UNIQUE,
      slug       TEXT NOT NULL UNIQUE,
      icon       TEXT,
      color      TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // ── articles ───────────────────────────────────────────────────────────────
  // Central table. Comes from NewsAPI (fetched_from='newsapi') or admin panel.
  // title_hi / summary_hi hold AI-generated Hindi translations.
  db.exec(`
    CREATE TABLE IF NOT EXISTS articles (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      title         TEXT NOT NULL,
      title_hi      TEXT,
      slug          TEXT NOT NULL UNIQUE,
      summary       TEXT,
      summary_hi    TEXT,
      content       TEXT,
      image_url     TEXT,
      source        TEXT,
      source_url    TEXT,
      author        TEXT,
      category_slug TEXT,
      is_breaking   INTEGER NOT NULL DEFAULT 0,
      is_hot        INTEGER NOT NULL DEFAULT 0,
      is_published  INTEGER NOT NULL DEFAULT 1,
      views         INTEGER NOT NULL DEFAULT 0,
      likes         INTEGER NOT NULL DEFAULT 0,
      tags          TEXT    DEFAULT '[]',
      language      TEXT    NOT NULL DEFAULT 'en',
      fetched_from  TEXT    DEFAULT 'manual',
      published_at  TEXT    NOT NULL DEFAULT (datetime('now')),
      created_at    TEXT    NOT NULL DEFAULT (datetime('now')),
      updated_at    TEXT    NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // Full-text search virtual table — enables fast MATCH queries
  db.exec(`
    CREATE VIRTUAL TABLE IF NOT EXISTS articles_fts
    USING fts5(
      title, summary, content, tags,
      content='articles',
      content_rowid='id'
    );
  `);

  // Keep FTS index in sync with the main table automatically
  db.exec(`
    CREATE TRIGGER IF NOT EXISTS articles_ai AFTER INSERT ON articles BEGIN
      INSERT INTO articles_fts(rowid, title, summary, content, tags)
      VALUES (new.id, new.title, COALESCE(new.summary,''), COALESCE(new.content,''), COALESCE(new.tags,''));
    END;

    CREATE TRIGGER IF NOT EXISTS articles_au AFTER UPDATE ON articles BEGIN
      INSERT INTO articles_fts(articles_fts, rowid, title, summary, content, tags)
      VALUES ('delete', old.id, old.title, COALESCE(old.summary,''), COALESCE(old.content,''), COALESCE(old.tags,''));
      INSERT INTO articles_fts(rowid, title, summary, content, tags)
      VALUES (new.id, new.title, COALESCE(new.summary,''), COALESCE(new.content,''), COALESCE(new.tags,''));
    END;

    CREATE TRIGGER IF NOT EXISTS articles_ad AFTER DELETE ON articles BEGIN
      INSERT INTO articles_fts(articles_fts, rowid, title, summary, content, tags)
      VALUES ('delete', old.id, old.title, COALESCE(old.summary,''), COALESCE(old.content,''), COALESCE(old.tags,''));
    END;
  `);

  // ── comments ───────────────────────────────────────────────────────────────
  // Supports both logged-in users (user_id set) and guests (guest_name set).
  // parent_id enables threaded/nested replies.
  db.exec(`
    CREATE TABLE IF NOT EXISTS comments (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      article_id  INTEGER NOT NULL REFERENCES articles(id) ON DELETE CASCADE,
      user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
      parent_id   INTEGER REFERENCES comments(id) ON DELETE CASCADE,
      guest_name  TEXT,
      guest_email TEXT,
      body        TEXT NOT NULL,
      is_approved INTEGER NOT NULL DEFAULT 1,
      likes       INTEGER NOT NULL DEFAULT 0,
      created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  // ── Seed categories ────────────────────────────────────────────────────────
  const insertCat = db.prepare(`
    INSERT OR IGNORE INTO categories (name, slug, icon, color)
    VALUES (?, ?, ?, ?)
  `);

  const categories = [
    ['India',         'india',         '🇮🇳', '#FF6600'],
    ['Politics',      'politics',      '🏛',  '#8B5CF6'],
    ['World',         'world',         '🌐',  '#0EA5E9'],
    ['Business',      'business',      '📈',  '#10B981'],
    ['Technology',    'tech',          '⚡',  '#6366F1'],
    ['Sports',        'sports',        '🏏',  '#E8001A'],
    ['Entertainment', 'entertainment', '🎬',  '#EC4899'],
    ['Health',        'health',        '💊',  '#10B981'],
    ['Science',       'science',       '🔬',  '#0891B2'],
    ['Crime',         'crime',         '⚖',  '#64748B'],
  ];

  const seedMany = db.transaction((rows) => rows.forEach(r => insertCat.run(...r)));
  seedMany(categories);

  // ── Seed default admin account ─────────────────────────────────────────────
  const adminExists = db.prepare('SELECT id FROM users WHERE role = ? LIMIT 1').get('admin');
  if (!adminExists) {
    const hash = bcrypt.hashSync(
      process.env.ADMIN_PASSWORD || 'Admin@2026!',
      12
    );
    db.prepare(`
      INSERT OR IGNORE INTO users (name, email, password, role)
      VALUES (?, ?, ?, 'admin')
    `).run(
      process.env.ADMIN_NAME  || 'Admin',
      process.env.ADMIN_EMAIL || 'admin@mahangapani.com',
      hash
    );
    console.log('✅  Default admin account created →', process.env.ADMIN_EMAIL);
  }

  console.log('✅  Database schema ready:', DB_PATH);
  return db;
}

module.exports = { getDb, initDatabase };
