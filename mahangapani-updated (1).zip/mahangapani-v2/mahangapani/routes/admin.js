/**
 * routes/admin.js
 * ───────────────
 * All routes here are double-guarded: authenticate (must be logged in)
 * AND requireAdmin (must have role = 'admin').
 *
 * GET  /api/v1/admin/stats        — dashboard headline numbers
 * GET  /api/v1/admin/users        — paginated user list
 * PUT  /api/v1/admin/users/:id    — update user role / status
 * GET  /api/v1/admin/comments     — all comments for moderation
 * GET  /api/v1/admin/articles     — all articles including drafts
 */

const router = require('express').Router();
const ctrl   = require('../controllers/adminController');
const { authenticate, requireAdmin } = require('../middleware/auth');

// Apply both guards to every admin route at once
router.use(authenticate, requireAdmin);

router.get('/stats',        ctrl.getStats);
router.get('/users',        ctrl.listUsers);
router.put('/users/:id',    ctrl.updateUser);
router.get('/comments',     ctrl.listComments);
router.get('/articles',     ctrl.listAllArticles);

module.exports = router;
