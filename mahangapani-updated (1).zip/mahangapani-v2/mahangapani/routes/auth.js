/**
 * routes/auth.js
 * ──────────────
 * Routes are kept intentionally thin — they just wire URLs to
 * controllers and attach middleware. All business logic lives
 * in the controller file.
 *
 * POST /api/v1/auth/register   → create account
 * POST /api/v1/auth/login      → get JWT
 * GET  /api/v1/auth/me         → get own profile (requires login)
 * PUT  /api/v1/auth/profile    → update profile (requires login)
 * PUT  /api/v1/auth/password   → change password (requires login)
 */

const router  = require('express').Router();
const ctrl    = require('../controllers/authController');
const { authenticate } = require('../middleware/auth');
const { registerRules, loginRules } = require('../middleware/validate');

router.post('/register',  registerRules, ctrl.register);
router.post('/login',     loginRules,    ctrl.login);
router.get('/me',         authenticate,  ctrl.me);
router.put('/profile',    authenticate,  ctrl.updateProfile);
router.put('/password',   authenticate,  ctrl.changePassword);

module.exports = router;
