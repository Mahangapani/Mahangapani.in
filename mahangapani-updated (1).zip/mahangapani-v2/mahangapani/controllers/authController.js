/**
 * controllers/authController.js
 * ─────────────────────────────
 * Handles all authentication flows:
 *   POST /api/v1/auth/register  — create a new user account
 *   POST /api/v1/auth/login     — verify credentials, return JWT
 *   GET  /api/v1/auth/me        — return the logged-in user's profile
 *   PUT  /api/v1/auth/profile   — update name, bio, avatar
 *   PUT  /api/v1/auth/password  — change password (requires current password)
 *
 * Security choices:
 *  - Passwords are hashed with bcrypt (cost factor 12). We never store plaintext.
 *  - JWTs are signed with the JWT_SECRET from .env. The token payload is minimal
 *    (just id + role) so if it leaks, no sensitive data is exposed.
 *  - We return the same generic error ("Invalid credentials") for both wrong email
 *    AND wrong password to prevent user enumeration attacks.
 */

const bcrypt = require('bcryptjs');
const jwt    = require('jsonwebtoken');
const config = require('../config');
const { getDb } = require('../database/migrate');

// ─── Helpers ─────────────────────────────────────────────────────────────────

/**
 * signToken
 * Creates a JWT containing just the user id and role.
 * The "role" claim lets the frontend show/hide admin UI without
 * making an extra API call.
 */
function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role },
    config.jwt.secret,
    { expiresIn: config.jwt.expiresIn }
  );
}

/**
 * safeUser
 * Strips the password hash before returning user data to the client.
 * Always use this when sending a user object in a response.
 */
function safeUser(user) {
  const { password: _, ...rest } = user;
  return rest;
}

// ─── register ────────────────────────────────────────────────────────────────

async function register(req, res, next) {
  try {
    const { name, email, password } = req.body;
    const db = getDb();

    // Check if this email is already registered
    const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    // Hash the password. Cost 12 = ~250ms on modern hardware, slow enough to
    // frustrate brute-force but fast enough for real users.
    const hash = await bcrypt.hash(password, 12);

    const result = db.prepare(`
      INSERT INTO users (name, email, password, role)
      VALUES (?, ?, ?, 'user')
    `).run(name, email, hash);

    const user  = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);
    const token = signToken(user);

    res.status(201).json({
      message: 'Account created successfully! Welcome to Mahangapani.',
      token,
      user: safeUser(user),
    });
  } catch (err) {
    next(err);
  }
}

// ─── login ───────────────────────────────────────────────────────────────────

async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    const db = getDb();

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

    // Use a constant-time comparison for the password check to prevent
    // timing attacks (where an attacker could tell from response time
    // whether the email exists).
    const passwordMatch = user ? await bcrypt.compare(password, user.password) : false;

    if (!user || !passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    if (!user.is_active) {
      return res.status(403).json({ error: 'Your account has been deactivated. Contact support.' });
    }

    const token = signToken(user);

    res.json({
      message: `Welcome back, ${user.name}!`,
      token,
      user: safeUser(user),
    });
  } catch (err) {
    next(err);
  }
}

// ─── me ──────────────────────────────────────────────────────────────────────
// Returns the profile of the currently logged-in user.
// The authenticate middleware has already attached req.user by this point.

function me(req, res) {
  const db   = getDb();
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json({ user: safeUser(user) });
}

// ─── updateProfile ───────────────────────────────────────────────────────────

async function updateProfile(req, res, next) {
  try {
    const { name, bio, avatar } = req.body;
    const db = getDb();

    db.prepare(`
      UPDATE users SET name = ?, bio = ?, avatar = ?, updated_at = datetime('now')
      WHERE id = ?
    `).run(name || req.user.name, bio || null, avatar || null, req.user.id);

    const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    res.json({ message: 'Profile updated.', user: safeUser(updated) });
  } catch (err) {
    next(err);
  }
}

// ─── changePassword ──────────────────────────────────────────────────────────

async function changePassword(req, res, next) {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'currentPassword and newPassword required.' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'New password must be at least 6 characters.' });
    }

    const db   = getDb();
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);

    const match = await bcrypt.compare(currentPassword, user.password);
    if (!match) {
      return res.status(401).json({ error: 'Current password is incorrect.' });
    }

    const newHash = await bcrypt.hash(newPassword, 12);
    db.prepare(`UPDATE users SET password = ?, updated_at = datetime('now') WHERE id = ?`)
      .run(newHash, req.user.id);

    res.json({ message: 'Password updated successfully.' });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login, me, updateProfile, changePassword };
